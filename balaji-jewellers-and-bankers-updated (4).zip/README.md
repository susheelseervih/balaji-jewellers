# Balaji Jewellers and Bankers — Website

A luxury jewellery e-commerce site built in React: gold/silver/bridal
catalogue, shop filters, product pages, wishlist & cart, and a "Banking
Counter" section for the gold loan / pawn broking side of the business.

## Use it right now

No build step needed. Open `dist/index.html` in a browser, or upload the
whole `dist` folder to any static host (Netlify, Vercel, GitHub Pages, cPanel,
etc.) — it's three files: `index.html`, `bundle.js`, `styles.css`.

The site needs an internet connection at runtime for two things only:
- Google Fonts (Cinzel / Jost / Cormorant Garamond)
- The Google Maps embed and the WhatsApp link

Everything else (React, routing, cart, filters) is bundled in and works
offline.

## Before you go live, replace these placeholders

1. **Product photography.** There's no real photography in this build, so
   each product shows a designed placeholder (a line-art icon on a gold/maroon
   card) instead of a broken image. Swap `<ProductVisual>` in
   `src/components/ProductCard.jsx` for a real `<img>` once you have photos —
   the surrounding markup won't need to change.
2. **Contact details** in `src/data.js` (`BRAND` object): phone number,
   WhatsApp number, email, address, and store timings are all placeholders.
3. **Prices** in `src/data.js` (`PRODUCTS` array) are illustrative, calculated
   at a rough gold rate. The product page already includes a disclaimer that
   prices track the day's gold rate — update the numbers to match your
   actual rate card.
4. **Store gallery** in `src/sections/Gallery.jsx` currently shows labelled
   placeholder tiles (`Showroom Interior`, `Vault & Security`, etc.) instead
   of real photos — same pattern as the product images.
5. **Google Maps** — `ContactSection.jsx` and `ContactPage.jsx` build a maps
   embed URL from the address in `data.js`. It'll resolve to whatever that
   address text search finds; for a precise pin, replace it with your
   Place ID embed URL from Google Maps' own "Share > Embed a map" tool.
6. **Checkout.** The cart currently ends at "Enquire to Checkout," which
   links to the Contact page — there's no payment gateway wired in. If you
   want online payment, that's the next real piece of engineering to add
   (Razorpay/Stripe are the common choices in India).

## Project structure

```
dist/                Ready-to-use build (open index.html directly)
src/
  data.js            All site content: brand info, categories, products,
                     testimonials, gallery labels — edit this file first
  context.jsx        Cart & wishlist state (React context)
  useHashRoute.js     Tiny hash-based router (#/shop, #/product/p1, etc.)
  App.jsx            Root layout, routing, cart/wishlist drawers
  components/        Shared UI: Icon set, Medallion (the coin/seal motif),
                     Navbar, Footer, ProductCard, Drawer, StarRating, Reveal
  sections/          Homepage sections (Hero, About, Categories, etc.)
  pages/             Shop, Product Detail, About, Contact, Reviews
  styles.css          Full hand-written stylesheet (no Tailwind/CSS
                     framework dependency)
```

## Making content changes

Almost everything on the site is data-driven from `src/data.js`:
categories, collections, "why choose us" points, banking services,
testimonials, gallery labels, and the product catalogue. Edit that file and
rebuild — you generally won't need to touch component code for copy changes.

## Rebuilding from source

The `dist` folder is already built and ready to use, so you only need this
if you edit anything in `src/`.

```bash
npm install
npm run build      # outputs dist/bundle.js
```

`npm run watch` rebuilds automatically while you edit.

## Design notes

- **Palette:** deep maroon (`#3d0a14`-`#8c1830`), antique gold
  (`#9c7a1b`-`#e7c766`), warm ivory (`#fbf6ec`), near-black (`#1b1410`).
- **Type:** Cinzel for headings (an engraved, coin-inscription character
  that ties into the medallion motif), Jost for body text, Cormorant
  Garamond italic for the one pull-quote per section.
- **Signature element:** the medallion/coin seal used in the hero, as the
  logo mark, and as a trust badge — a deliberate visual pun on the brand's
  two identities, jeweller (the gold) and banker (the struck coin).
- **No icon library / no Tailwind CDN.** Icons are a small hand-drawn set in
  `components/Icon.jsx`, and all styling is plain CSS, so the site has zero
  runtime dependency on a CDN for either.

## Browser support

Built and tested against current Chromium. Uses CSS Grid, `aspect-ratio`,
and `IntersectionObserver` — all standard in any browser from the last
several years.
