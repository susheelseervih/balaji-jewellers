import React from "react";
import Icon from "./Icon.jsx";

export default function StarRating({ rating, size = 16 }) {
  return (
    <div className="star-rating" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={i < rating ? "star-filled" : "star-empty"}>
          <Icon name="star" size={size} filled={i < rating} strokeWidth={1.3} />
        </span>
      ))}
    </div>
  );
}
