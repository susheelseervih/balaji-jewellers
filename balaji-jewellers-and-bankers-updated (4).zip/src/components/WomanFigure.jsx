import React from "react";

// An abstract, illustrated silhouette used as a full-bleed hero background --
// there is no photography available in this build, so rather than a stock
// photo (which wouldn't match the brand) or a fake photorealistic render,
// this commits fully to illustration: a fashion-silhouette figure wearing
// the piece each slide is about. Same base figure throughout for cohesion;
// only the jewellery accent changes.
export default function WomanFigure({ jewelry = "necklace", className = "" }) {
  return (
    <svg
      viewBox="0 0 480 640"
      preserveAspectRatio="xMidYMax slice"
      className={`woman-figure ${className}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`skinGrad-${jewelry}`} x1="0" y1="0" x2="1" y2="0.3">
          <stop offset="0" stopColor="#a5354a" />
          <stop offset="0.55" stopColor="#5c0f1f" />
          <stop offset="1" stopColor="#1b1410" />
        </linearGradient>
      </defs>

      {/* base silhouette: head -> neck -> shoulder -> torso */}
      <path
        d="M270 80 C285 68 315 68 330 80 C352 95 362 115 362 140
           C362 165 354 186 340 200 C330 212 322 220 318 232
           C340 248 368 258 392 272 C430 296 452 336 460 384
           C472 444 476 540 478 640 L122 640
           C124 540 128 444 140 384 C148 336 170 296 208 272
           C232 258 260 248 282 232 C278 220 270 212 260 200
           C246 186 238 165 238 140 C238 115 248 95 270 80 Z"
        fill={`url(#skinGrad-${jewelry})`}
        stroke="#c9a227"
        strokeWidth="1.5"
        opacity="0.97"
      />

      {/* hair bun + ornament */}
      <circle cx="312" cy="76" r="26" fill="#120b09" />
      <circle cx="286" cy="52" r="3" fill="#e7c766" />
      <circle cx="316" cy="44" r="3" fill="#e7c766" />
      <circle cx="340" cy="56" r="3" fill="#e7c766" />

      {/* rim light */}
      <path d="M238 140C238 115 248 95 270 80" stroke="#f3d98a" strokeWidth="2" fill="none" opacity="0.55" />
      <path d="M208 272C170 296 148 336 140 384" stroke="#f3d98a" strokeWidth="1.5" fill="none" opacity="0.4" />

      {/* earring: present in every variant, more elaborate for the earrings slide */}
      <circle cx="345" cy="206" r="3.2" fill="#e7c766" />
      <path d="M345 210q7 12 0 26" stroke="#e7c766" strokeWidth="2" fill="none" />
      <circle cx="345" cy="240" r="4" fill="#e7c766" />
      {jewelry === "earrings" && (
        <>
          <path d="M345 244q10 14 0 30" stroke="#e7c766" strokeWidth="1.6" fill="none" />
          <circle cx="345" cy="278" r="3.4" fill="#e7c766" />
        </>
      )}

      {jewelry === "necklace" && (
        <>
          <path d="M232 288Q300 336 372 288" stroke="#e7c766" strokeWidth="2.5" fill="none" opacity="0.95" />
          <path d="M216 306Q300 372 388 306" stroke="#e7c766" strokeWidth="2.5" fill="none" opacity="0.95" />
          <path d="M292 356l10 12-10 12-10-12z" fill="#e7c766" />
        </>
      )}

      {jewelry === "earrings" && (
        <path d="M240 300Q300 336 364 300" stroke="#e7c766" strokeWidth="2.2" fill="none" opacity="0.85" />
      )}

      {(jewelry === "bangles" || jewelry === "ring") && (
        <g>
          {/* a raised hand resting near the collarbone, softly stylised */}
          <ellipse cx="252" cy="330" rx="30" ry="40" transform="rotate(-18 252 330)" fill={`url(#skinGrad-${jewelry})`} stroke="#c9a227" strokeWidth="1.3" />
          {jewelry === "bangles" && (
            <>
              <ellipse cx="238" cy="368" rx="26" ry="8" transform="rotate(-18 238 368)" fill="none" stroke="#e7c766" strokeWidth="2.2" />
              <ellipse cx="234" cy="380" rx="26" ry="8" transform="rotate(-18 234 380)" fill="none" stroke="#e7c766" strokeWidth="2.2" />
              <ellipse cx="230" cy="392" rx="26" ry="8" transform="rotate(-18 230 392)" fill="none" stroke="#e7c766" strokeWidth="2.2" />
            </>
          )}
          {jewelry === "ring" && (
            <ellipse cx="262" cy="300" rx="6" ry="5" fill="none" stroke="#e7c766" strokeWidth="2.2" />
          )}
          <path d="M232 292Q300 332 366 296" stroke="#e7c766" strokeWidth="2" fill="none" opacity="0.6" />
        </g>
      )}

      {/* sparkle accents */}
      <path d="M120 200l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#e7c766" opacity="0.7" />
      <path d="M410 460l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="#e7c766" opacity="0.5" />
    </svg>
  );
}
