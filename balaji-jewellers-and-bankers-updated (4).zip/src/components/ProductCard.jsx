import React from "react";
import Icon from "./Icon.jsx";
import StarRating from "./StarRating.jsx";
import { formatINR } from "../data.js";
import { useShop } from "../context.jsx";

// No product photography is available in this build, so each item gets a
// designed placeholder: a line-art icon of the piece on a deep gradient
// card, rather than a broken image or a grey box. Swap <ProductVisual> for
// a real <img> when photography is ready -- the surrounding markup won't
// need to change.
export function ProductVisual({ icon, className = "" }) {
  return (
    <div className={`product-visual ${className}`}>
      <Icon name={icon} size={56} strokeWidth={1} />
    </div>
  );
}

export default function ProductCard({ product, onOpen }) {
  const { addToCart, toggleWishlist, wishlist } = useShop();
  const isWishlisted = wishlist.includes(product.id);

  return (
    <div className="product-card">
      <button
        className="product-card-visual zoom-box"
        onClick={() => onOpen(product.id)}
        aria-label={`View ${product.name}`}
      >
        <ProductVisual icon={product.icon} className="zoom-target" />
        <span className={`wish-toggle ${isWishlisted ? "active" : ""}`}
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          role="button"
          aria-label="Toggle wishlist"
        >
          <Icon name="heart" size={18} filled={isWishlisted} />
        </span>
      </button>
      <div className="product-card-body">
        <p className="product-meta">{product.metal} &middot; {product.purity} &middot; {product.weight}g</p>
        <h3 className="product-name" onClick={() => onOpen(product.id)}>{product.name}</h3>
        <p className="product-price">{formatINR(product.price)}</p>
        <div className="product-card-actions">
          <button className="btn btn-ghost btn-sm" onClick={() => onOpen(product.id)}>
            View
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => addToCart(product.id)}>
            <Icon name="bag" size={16} /> Add
          </button>
        </div>
      </div>
    </div>
  );
}
