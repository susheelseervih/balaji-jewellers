import React from "react";
import Icon from "./Icon.jsx";
import { BRAND } from "../data.js";

export default function WhatsAppFAB() {
  const link = `https://wa.me/${BRAND.whatsapp}?text=${encodeURIComponent(
    "Hello, I'd like to know more about your jewellery collections."
  )}`;
  return (
    <a href={link} target="_blank" rel="noopener noreferrer" className="whatsapp-fab" aria-label="Chat on WhatsApp">
      <Icon name="whatsapp" size={26} />
    </a>
  );
}
