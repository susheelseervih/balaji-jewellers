import React from "react";

// The recurring signature motif: an engraved coin/seal that stands in for
// both halves of the brand -- a struck coin (banking) and a piece of
// jewellery (the gold itself). Used at hero scale, as a trust badge, and
// as small icon frames in feature lists.
export default function Medallion({ size = 120, shimmer = false, children, className = "" }) {
  const ticks = Array.from({ length: 40 });
  return (
    <div
      className={`medallion ${shimmer ? "medallion-shimmer" : ""} ${className}`}
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 200 200" width="100%" height="100%">
        <circle cx="100" cy="100" r="96" className="medallion-rim" />
        {ticks.map((_, i) => {
          const angle = (i / ticks.length) * 360;
          return (
            <line
              key={i}
              x1="100"
              y1="6"
              x2="100"
              y2="14"
              className="medallion-tick"
              transform={`rotate(${angle} 100 100)`}
            />
          );
        })}
        <circle cx="100" cy="100" r="82" className="medallion-ring-outer" />
        <circle cx="100" cy="100" r="70" className="medallion-ring-inner" />
      </svg>
      <div className="medallion-center">{children}</div>
    </div>
  );
}
