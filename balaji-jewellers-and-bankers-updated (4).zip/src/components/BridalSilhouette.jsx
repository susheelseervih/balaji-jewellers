import React from "react";

// A deliberately abstract fashion-sketch silhouette -- no photography is
// available in this build, so rather than a stock photo or a fake
// "realistic" render, this leans fully into illustration: a bust outline
// wearing a layered necklace, earring and hair ornament, drawn in the same
// gold line-art language as the icon set.
export default function BridalSilhouette({ size = 200 }) {
  return (
    <svg viewBox="0 0 220 260" width={size} height={size * (260 / 220)} fill="none" aria-hidden="true">
      {/* hair bun + ornament dots */}
      <circle cx="140" cy="34" r="17" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="118" cy="20" r="2.4" fill="currentColor" />
      <circle cx="160" cy="22" r="2.4" fill="currentColor" />
      <circle cx="150" cy="12" r="2.4" fill="currentColor" />

      {/* head */}
      <ellipse cx="110" cy="58" rx="34" ry="38" stroke="currentColor" strokeWidth="1.4" />

      {/* earring */}
      <circle cx="134" cy="92" r="2.2" fill="currentColor" />
      <path d="M134 95q6 9 0 19" stroke="currentColor" strokeWidth="1.4" />

      {/* neck */}
      <path d="M92 90c-2 16-4 28-6 40" stroke="currentColor" strokeWidth="1.4" />
      <path d="M128 90c2 16 4 28 6 40" stroke="currentColor" strokeWidth="1.4" />

      {/* shoulders / drape */}
      <path
        d="M14 230c8-58 55-98 96-98s88 40 96 98"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path d="M14 230l-8 28" stroke="currentColor" strokeWidth="1.4" />
      <path d="M206 230l8 28" stroke="currentColor" strokeWidth="1.4" />

      {/* necklace: choker + longer layer with pendant */}
      <path d="M78 132q32 24 64 0" stroke="currentColor" strokeWidth="1.5" />
      <path d="M65 140q45 46 90 0" stroke="currentColor" strokeWidth="1.5" />
      <path d="M110 172l9 9-9 9-9-9z" stroke="currentColor" strokeWidth="1.4" />

      {/* small sparkle accents */}
      <path d="M26 70l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="currentColor" opacity="0.8" />
      <path d="M196 150l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="currentColor" opacity="0.7" />
    </svg>
  );
}
