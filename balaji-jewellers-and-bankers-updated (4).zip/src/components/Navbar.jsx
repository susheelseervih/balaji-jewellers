import React, { useEffect, useState } from "react";
import Icon from "./Icon.jsx";
import { BRAND, CATEGORY_MENU, GOLD_LOAN_MENU, CUSTOM_ORDERS_LINE } from "../data.js";
import { useShop } from "../context.jsx";

const LINKS = [
  { to: "#/", label: "Home" },
  { to: "#/calculator", label: "Rate Calculator" },
  { to: "#/about", label: "About" },
  { to: "#/reviews", label: "Reviews" },
  { to: "#/contact", label: "Contact" },
];

export default function Navbar({ currentPath, onSearch }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [megaOpen, setMegaOpen] = useState(false);
  const [loanOpen, setLoanOpen] = useState(false);
  const [mobileCatOpen, setMobileCatOpen] = useState(false);
  const [mobileLoanOpen, setMobileLoanOpen] = useState(false);
  const { cart, wishlist, setCartOpen, setWishlistOpen } = useShop();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMegaOpen(false);
    setLoanOpen(false);
    setMobileOpen(false);
  }, [currentPath]);

  function submitSearch(e) {
    e.preventDefault();
    window.location.hash = "#/shop";
    onSearch(query);
    setSearchOpen(false);
  }

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const isActive = (to) =>
    currentPath === to.replace("#/", "").split("/")[0] || (to === "#/" && currentPath === "home");

  return (
    <header className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <div className="announce-ribbon">
        <span className="announce-en">✨ {CUSTOM_ORDERS_LINE.en}</span>
        <span className="announce-kn">{CUSTOM_ORDERS_LINE.kn}</span>
      </div>
      <div className="navbar-inner">
        <a href="#/" className="brand-mark">
          <img src="logo.png" alt={`${BRAND.name} logo`} className="brand-logo" width={46} height={46} />
          <span className="brand-name">
            Balaji Jewellers <em>&amp; Bankers</em>
          </span>
        </a>

        <nav className="navbar-links" aria-label="Primary">
          <a href="#/" className={isActive("#/") ? "active" : ""}>Home</a>

          <div
            className="nav-mega-trigger"
            onMouseEnter={() => setMegaOpen(true)}
            onMouseLeave={() => setMegaOpen(false)}
          >
            <a href="#/categories" className={`nav-mega-label ${currentPath === "categories" ? "active" : ""}`}>
              Jewellery Categories <Icon name="chevronRight" size={13} className="rotate-90" />
            </a>
            {megaOpen && (
              <div className="nav-mega-panel">
                <div className="nav-mega-columns">
                  {CATEGORY_MENU.map((cat) => (
                    <div key={cat.id} className="nav-mega-col">
                      <a href={`#/categories/${cat.id}`} className="nav-mega-col-title">
                        <span>{cat.emoji}</span> {cat.name}
                      </a>
                      <ul>
                        {cat.sections[0].items.slice(0, 6).map((item) => (
                          <li key={item.name}>
                            <a href={`#/categories/${cat.id}`}>{item.name}</a>
                          </li>
                        ))}
                      </ul>
                      <a href={`#/categories/${cat.id}`} className="nav-mega-col-more">
                        View All <Icon name="chevronRight" size={12} />
                      </a>
                    </div>
                  ))}
                </div>
                <div className="nav-mega-footer">
                  <Icon name="pencil" size={15} /> {CUSTOM_ORDERS_LINE.en}
                </div>
              </div>
            )}
          </div>

          <div
            className="nav-mega-trigger"
            onMouseEnter={() => setLoanOpen(true)}
            onMouseLeave={() => setLoanOpen(false)}
          >
            <a href="#/gold-loan" className={`nav-mega-label nav-loan-label ${currentPath === "gold-loan" ? "active" : ""}`}>
              💰 Gold Loan <Icon name="chevronRight" size={13} className="rotate-90" />
            </a>
            {loanOpen && (
              <div className="nav-loan-panel">
                <p className="nav-loan-banner">{GOLD_LOAN_MENU.banner}</p>
                <ul>
                  {GOLD_LOAN_MENU.items.map((item) => (
                    <li key={item.name}>
                      <a href="#/gold-loan">
                        <Icon name={item.icon} size={16} /> {item.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {LINKS.slice(1).map((link) => (
            <a key={link.to} href={link.to} className={isActive(link.to) ? "active" : ""}>
              {link.label}
            </a>
          ))}
        </nav>

        <div className="navbar-actions">
          <button className="icon-btn" aria-label="Search" onClick={() => setSearchOpen((s) => !s)}>
            <Icon name="search" size={20} />
          </button>
          <button className="icon-btn" aria-label="Wishlist" onClick={() => setWishlistOpen(true)}>
            <Icon name="heart" size={20} />
            {wishlist.length > 0 && <span className="badge">{wishlist.length}</span>}
          </button>
          <button className="icon-btn" aria-label="Cart" onClick={() => setCartOpen(true)}>
            <Icon name="bag" size={20} />
            {cartCount > 0 && <span className="badge">{cartCount}</span>}
          </button>
          <button
            className="icon-btn mobile-toggle"
            aria-label="Menu"
            onClick={() => setMobileOpen((s) => !s)}
          >
            <Icon name={mobileOpen ? "close" : "menu"} size={22} />
          </button>
        </div>
      </div>

      {searchOpen && (
        <form className="navbar-search" onSubmit={submitSearch}>
          <Icon name="search" size={18} />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for necklaces, bangles, coins..."
          />
          <button type="submit" className="btn btn-primary btn-sm">Search</button>
        </form>
      )}

      {mobileOpen && (
        <nav className="navbar-mobile" aria-label="Mobile">
          <a href="#/" onClick={() => setMobileOpen(false)}>Home</a>

          <div className="mobile-accordion">
            <button className="mobile-accordion-head" onClick={() => setMobileCatOpen((s) => !s)}>
              Jewellery Categories
              <Icon name="chevronRight" size={14} className={mobileCatOpen ? "rotate-90" : ""} />
            </button>
            {mobileCatOpen && (
              <div className="mobile-accordion-body">
                {CATEGORY_MENU.map((cat) => (
                  <a key={cat.id} href={`#/categories/${cat.id}`} onClick={() => setMobileOpen(false)}>
                    {cat.emoji} {cat.name}
                  </a>
                ))}
                <a href="#/categories" className="mobile-accordion-viewall" onClick={() => setMobileOpen(false)}>
                  View All Categories
                </a>
              </div>
            )}
          </div>

          <div className="mobile-accordion">
            <button className="mobile-accordion-head" onClick={() => setMobileLoanOpen((s) => !s)}>
              💰 Gold Loan
              <Icon name="chevronRight" size={14} className={mobileLoanOpen ? "rotate-90" : ""} />
            </button>
            {mobileLoanOpen && (
              <div className="mobile-accordion-body">
                {GOLD_LOAN_MENU.items.map((item) => (
                  <a key={item.name} href="#/gold-loan" onClick={() => setMobileOpen(false)}>
                    {item.name}
                  </a>
                ))}
              </div>
            )}
          </div>

          {LINKS.slice(1).map((link) => (
            <a key={link.to} href={link.to} onClick={() => setMobileOpen(false)}>
              {link.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
