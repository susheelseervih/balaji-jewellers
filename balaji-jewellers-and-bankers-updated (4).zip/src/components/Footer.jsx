import React from "react";
import Icon from "./Icon.jsx";
import { BRAND, CATEGORY_MENU } from "../data.js";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="coin-edge" />
      <div className="footer-inner">
        <div className="footer-col footer-brand">
          <div className="brand-mark">
            <img src="logo.png" alt={`${BRAND.name} logo`} className="brand-logo" width={50} height={50} />
            <span className="brand-name light">
              Balaji Jewellers <em>&amp; Bankers</em>
            </span>
          </div>
          <p>Serving customers for 35+ years, out of Nagamangala, Karnataka.</p>
          <div className="social-icons">
            <a href="#" aria-label="Facebook" className="icon-btn">FB</a>
            <a href="#" aria-label="Instagram" className="icon-btn">IG</a>
            <a href="#" aria-label="YouTube" className="icon-btn">YT</a>
          </div>
        </div>

        <div className="footer-col">
          <h4>Quick Links</h4>
          <a href="#/">Home</a>
          <a href="#/categories">Jewellery Categories</a>
          <a href="#/gold-loan">Gold Loan</a>
          <a href="#/calculator">Rate Calculator</a>
          <a href="#/about">About Us</a>
          <a href="#/reviews">Reviews</a>
          <a href="#/contact">Contact</a>
        </div>

        <div className="footer-col">
          <h4>Categories</h4>
          {CATEGORY_MENU.filter((c) => !["kids", "mens"].includes(c.id)).map((c) => (
            <a key={c.id} href={`#/categories/${c.id}`}>{c.emoji} {c.name}</a>
          ))}
        </div>

        <div className="footer-col">
          <h4>Contact</h4>
          <p><Icon name="pin" size={16} /> {BRAND.address}</p>
          <p><Icon name="phone" size={16} /> {BRAND.phone} ({BRAND.phoneOwner})</p>
          <p><Icon name="phone" size={16} /> {BRAND.phone2} ({BRAND.phone2Owner})</p>
          <p><Icon name="whatsapp" size={16} /> Chat on WhatsApp</p>
          <p className="footer-holiday">{BRAND.holidayNote}</p>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="trust-badge">
          <Icon name="shield" size={16} /> Serving Customers for 35+ Years
        </div>
        <p>&copy; {new Date().getFullYear()} {BRAND.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}
