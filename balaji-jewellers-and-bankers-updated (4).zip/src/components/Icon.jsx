import React from "react";

// A small, hand-drawn line-icon set so the whole site shares one visual
// language instead of pulling in a generic icon library.
const PATHS = {
  necklace: (
    <>
      <path d="M5 6c0 7 5.5 12 11 12s11-5 11-12" />
      <circle cx="16" cy="21" r="2.6" />
    </>
  ),
  ring: (
    <>
      <circle cx="16" cy="19" r="7" />
      <path d="M12.5 12L16 5l3.5 7" />
      <path d="M13.2 10.5h5.6" />
    </>
  ),
  bangle: (
    <>
      <ellipse cx="16" cy="16" rx="10" ry="10" />
      <ellipse cx="16" cy="16" rx="6.2" ry="6.2" />
    </>
  ),
  earring: (
    <>
      <path d="M12.5 7a3.5 3.5 0 1 1 7 0c0 1.8-1.4 2.6-2.7 3.6" />
      <line x1="16.3" y1="12.2" x2="16.3" y2="15.5" />
      <circle cx="16.3" cy="19.5" r="3.6" />
    </>
  ),
  chain: (
    <>
      <ellipse cx="10" cy="12" rx="4" ry="5.2" transform="rotate(-20 10 12)" />
      <ellipse cx="16.5" cy="17" rx="4" ry="5.2" transform="rotate(-20 16.5 17)" />
      <ellipse cx="23" cy="22" rx="4" ry="5.2" transform="rotate(-20 23 22)" />
    </>
  ),
  bridal: (
    <>
      <path d="M6 8c0 8 6 14 10 14S26 16 26 8" />
      <path d="M9.5 8c0 6 4.2 10.5 6.5 10.5S22.5 14 22.5 8" />
      <circle cx="16" cy="23" r="2.4" />
    </>
  ),
  coin: (
    <>
      <circle cx="16" cy="16" r="10.5" />
      <circle cx="16" cy="16" r="7" />
      <path d="M16 12.2v7.6M13.4 14.2h5.2M13.4 17.8h5.2" />
    </>
  ),
  lamp: (
    <>
      <path d="M16 5v3" />
      <path d="M11 8h10l-2 5H13z" />
      <path d="M12 13c-2 3-3 6-3 8.5A7 7 0 0 0 16 27a7 7 0 0 0 7-5.5c0-2.5-1-5.5-3-8.5" />
    </>
  ),
  shield: (
    <>
      <path d="M16 5l9 3.4v6.4c0 6-4 10-9 12-5-2-9-6-9-12V8.4z" />
      <path d="M12 16l3 3 5.5-6" />
    </>
  ),
  certificate: (
    <>
      <rect x="6" y="6" width="20" height="14" rx="1.5" />
      <path d="M9.5 10.5h13M9.5 14h9" />
      <circle cx="16" cy="24.5" r="3.2" />
      <path d="M13.8 26.8L12.8 31l3.2-1.8 3.2 1.8-1-4.2" />
    </>
  ),
  scale: (
    <>
      <path d="M16 6v20M9 26h14" />
      <path d="M6 10h9M17 10h9" />
      <path d="M6 10l-3.5 7a3.7 3.7 0 0 0 7 0z" />
      <path d="M26 10l-3.5 7a3.7 3.7 0 0 0 7 0z" />
    </>
  ),
  pencil: (
    <>
      <path d="M20.5 6.5l5 5L11 26l-5.5 1.5L7 22z" />
      <path d="M18 9l5 5" />
    </>
  ),
  vault: (
    <>
      <rect x="5" y="6" width="22" height="20" rx="1.5" />
      <circle cx="16" cy="16" r="5.5" />
      <circle cx="16" cy="16" r="1.4" />
      <path d="M16 10.5V12M16 20v1.5M10.5 16H12M20 16h1.5" />
    </>
  ),
  lock: (
    <>
      <rect x="8" y="14" width="16" height="12" rx="1.5" />
      <path d="M11 14v-3a5 5 0 0 1 10 0v3" />
      <circle cx="16" cy="19.5" r="1.6" />
    </>
  ),
  handshake: (
    <>
      <path d="M4 15l5-4 5 3 2-2 5 4" />
      <path d="M9 14l5 5 2-2" />
      <path d="M16 17l2 2 2-2 4 3-3 4-3-1" />
    </>
  ),
  phone: (
    <>
      <path d="M9 6h4l1.5 5-3 2a13 13 0 0 0 6.5 6.5l2-3 5 1.5v4a2 2 0 0 1-2.2 2C14 23.5 8.5 18 6.5 9.2A2 2 0 0 1 9 6z" />
    </>
  ),
  whatsapp: (
    <>
      <path d="M8 24l1.3-4.6A9 9 0 1 1 13 22z" />
      <path d="M11.7 12.8c-.3.9 0 2.1.9 3.4 1 1.4 2.4 2.4 4 2.8 1 .3 1.6-.1 1.9-.6l.3-.7c.1-.3 0-.6-.3-.8l-1.5-.9c-.3-.2-.6-.1-.8.1l-.4.5c-.7-.3-1.6-1-2.1-1.9l.4-.5c.2-.2.2-.5.1-.8l-.8-1.6c-.1-.3-.4-.4-.7-.3z" />
    </>
  ),
  pin: (
    <>
      <path d="M16 27s8-7.6 8-13.5A8 8 0 0 0 8 13.5C8 19.4 16 27 16 27z" />
      <circle cx="16" cy="13.5" r="3" />
    </>
  ),
  search: (
    <>
      <circle cx="14" cy="14" r="8" />
      <path d="M20 20l6 6" />
    </>
  ),
  heart: (
    <path d="M16 27S5 20 5 12.8A5.8 5.8 0 0 1 16 9.5a5.8 5.8 0 0 1 11 3.3C27 20 16 27 16 27z" />
  ),
  bag: (
    <>
      <path d="M8 12h16l-1.3 15H9.3z" />
      <path d="M12 12V9a4 4 0 0 1 8 0v3" />
    </>
  ),
  star: (
    <path d="M16 4.5l3.4 7 7.6 1.1-5.5 5.4 1.3 7.6L16 22l-6.8 3.6 1.3-7.6L5 12.6l7.6-1.1z" />
  ),
  menu: (
    <>
      <path d="M5 9h22M5 16h22M5 23h22" />
    </>
  ),
  close: (
    <path d="M8 8l16 16M24 8L8 24" />
  ),
  chevronRight: <path d="M12 6l10 10-10 10" />,
  chevronDown: <path d="M6 12l10 10 10-10" />,
  minus: <path d="M8 16h16" />,
  plus: <path d="M16 8v16M8 16h16" />,
  filter: (
    <path d="M5 8h22M10 16h12M14 24h4" />
  ),
  truck: (
    <>
      <path d="M4 10h13v11H4z" />
      <path d="M17 14h5l4 4v3h-9z" />
      <circle cx="9" cy="24" r="2.2" />
      <circle cx="22" cy="24" r="2.2" />
    </>
  ),
  tali: (
    <>
      <path d="M6 9c0 6.5 4.5 11 10 11s10-4.5 10-11" />
      <circle cx="16" cy="24" r="3.4" />
      <circle cx="10.5" cy="16.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="21.5" cy="16.5" r="1" fill="currentColor" stroke="none" />
    </>
  ),
  nosePin: (
    <>
      <circle cx="16" cy="19" r="5" />
      <circle cx="16" cy="19" r="1.3" fill="currentColor" stroke="none" />
      <path d="M18.5 15.5c1.5-2 1.5-5-0.5-7" />
    </>
  ),
  bracelet: (
    <>
      <ellipse cx="16" cy="17" rx="10" ry="6.5" />
      <circle cx="16" cy="23.5" r="1.8" fill="currentColor" stroke="none" />
    </>
  ),
  anklet: (
    <>
      <ellipse cx="16" cy="17" rx="12" ry="5.5" />
      <circle cx="9" cy="20.5" r="1.3" fill="currentColor" stroke="none" />
      <circle cx="16" cy="22.5" r="1.3" fill="currentColor" stroke="none" />
      <circle cx="23" cy="20.5" r="1.3" fill="currentColor" stroke="none" />
    </>
  ),
  hairAccessory: (
    <>
      <path d="M7 6v20" />
      <path d="M12.5 6v20" />
      <path d="M18 6v20" />
      <path d="M23.5 6v20" />
      <path d="M5.5 6h20" />
    </>
  ),
  plate: (
    <>
      <circle cx="16" cy="16" r="11" />
      <circle cx="16" cy="16" r="6" />
    </>
  ),
  idol: (
    <>
      <path d="M16 4.5c-2.8 0-4.8 2.2-4.8 5 0 1.9 1 3.4 2.4 4.3L10 26.5h12l-3.6-12.7c1.4-0.9 2.4-2.4 2.4-4.3 0-2.8-2-5-4.8-5z" />
      <path d="M12 21h8" />
    </>
  ),
  gift: (
    <>
      <rect x="6" y="14" width="20" height="12.5" rx="1.4" />
      <path d="M6 18.5h20" />
      <path d="M16 14v12.5" />
      <path d="M16 14c-1.8-4.2-8-4-8 0.3" />
      <path d="M16 14c1.8-4.2 8-4 8 0.3" />
    </>
  ),
  vaddanam: (
    <>
      <path d="M5 13c0 6.5 5 11 11 11s11-4.5 11-11" />
      <circle cx="16" cy="25.5" r="1.7" fill="currentColor" stroke="none" />
      <circle cx="10.5" cy="23" r="1.3" fill="currentColor" stroke="none" />
      <circle cx="21.5" cy="23" r="1.3" fill="currentColor" stroke="none" />
    </>
  ),
  diamond: (
    <>
      <path d="M8 12h16l-8 15z" />
      <path d="M8 12l4-6h8l4 6" />
      <path d="M12.2 12l3.8 15 3.8-15" />
    </>
  ),
  kids: (
    <>
      <path d="M16 5l2.7 6.4 6.9 0.6-5.2 4.6 1.6 6.8L16 19.8l-6 3.6 1.6-6.8-5.2-4.6 6.9-0.6z" />
    </>
  ),
  mattal: (
    <>
      <path d="M19 8c2.2 0 4 1.9 4 4.2 0 2.3-1.8 3.5-3.3 4.6" />
      <path d="M19.7 16.8c2.7 1.2 3.7 4.3 2.6 8" />
      <circle cx="22.3" cy="25" r="1.7" fill="currentColor" stroke="none" />
    </>
  ),
};

export default function Icon({ name, size = 24, strokeWidth = 1.5, className = "", filled = false }) {
  const content = PATHS[name];
  if (!content) return null;
  return (
    <svg
      className={`icon icon-${name} ${className}`}
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {content}
    </svg>
  );
}
