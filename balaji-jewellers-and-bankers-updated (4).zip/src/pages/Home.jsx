import React from "react";
import Hero from "../sections/Hero.jsx";
import About from "../sections/About.jsx";
import Categories from "../sections/Categories.jsx";
import FeaturedCollections from "../sections/FeaturedCollections.jsx";
import WhyChooseUs from "../sections/WhyChooseUs.jsx";
import BankingServices from "../sections/BankingServices.jsx";
import Testimonials from "../sections/Testimonials.jsx";
import ContactSection from "../sections/ContactSection.jsx";

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Categories />
      <FeaturedCollections />
      <WhyChooseUs />
      <BankingServices />
      <Testimonials />
      <ContactSection />
    </>
  );
}
