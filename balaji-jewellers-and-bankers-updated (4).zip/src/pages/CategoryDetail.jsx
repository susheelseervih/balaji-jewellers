import React, { useState } from "react";
import Icon from "../components/Icon.jsx";
import Reveal from "../components/Reveal.jsx";
import { CATEGORY_MENU, BRAND } from "../data.js";

export default function CategoryDetail({ categoryId }) {
  const category = CATEGORY_MENU.find((c) => c.id === categoryId);
  const [expanded, setExpanded] = useState({});

  if (!category) {
    return (
      <section className="section">
        <div className="section-inner" style={{ textAlign: "center" }}>
          <p className="eyebrow">Category Not Found</p>
          <h1>We couldn't find that category</h1>
          <a href="#/categories" className="btn btn-primary btn-lg" style={{ marginTop: "1.5rem" }}>
            Browse All Categories
          </a>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="section page-header category-detail-header">
        <div className="section-inner">
          <a href="#/categories" className="category-back-link">
            <Icon name="chevronRight" size={14} className="rotate-180" /> All Categories
          </a>
          <p className="eyebrow">{category.emoji} Jewellery Category</p>
          <h1>{category.name}</h1>
          {category.banner && <div className="category-banner">{category.banner}</div>}
        </div>
      </section>

      <section className="section category-detail-body">
        <div className="section-inner">
          {category.sections.map((section) => {
            const isCollapsible = !!section.collapsible;
            const isOpen = expanded[section.title] ?? !isCollapsible;
            return (
              <div key={section.title} className="category-section-block">
                <div className="category-section-head">
                  <h2>{section.title}</h2>
                  {isCollapsible && (
                    <button
                      className="category-more-toggle"
                      onClick={() => setExpanded((e) => ({ ...e, [section.title]: !isOpen }))}
                    >
                      {isOpen ? "Show Less" : "More"}
                      <Icon name="chevronRight" size={14} className={isOpen ? "rotate-90" : "rotate-neg-90"} />
                    </button>
                  )}
                </div>
                {isOpen && (
                  <div className="category-item-grid">
                    {section.items.map((item) => (
                      <Reveal key={item.name} as="div" className="category-item-card">
                        <div className="category-item-visual">
                          {item.image ? (
                            <img src={item.image} alt={item.name} className="category-item-photo" />
                          ) : (
                            <Icon name={item.icon} size={44} strokeWidth={1.1} />
                          )}
                        </div>
                        <p className="category-item-name">{item.name}</p>
                        <a
                          href={`https://wa.me/${BRAND.whatsapp}?text=${encodeURIComponent(`Hi, I'd like to know more about ${item.name}`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="category-item-enquire"
                        >
                          Enquire <Icon name="whatsapp" size={13} />
                        </a>
                      </Reveal>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          <div className="category-detail-cta">
            <p>Every piece can be customised in weight, purity, and design.</p>
            <a href={`https://wa.me/${BRAND.whatsapp}`} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-lg">
              <Icon name="whatsapp" size={18} /> Chat With Us
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
