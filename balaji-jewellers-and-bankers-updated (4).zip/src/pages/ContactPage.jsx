import React, { useState } from "react";
import Icon from "../components/Icon.jsx";
import Reveal from "../components/Reveal.jsx";
import { BRAND } from "../data.js";

export default function ContactPage() {
  const [sent, setSent] = useState(false);
  const waLink = `https://wa.me/${BRAND.whatsapp}`;

  function handleSubmit(e) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <>
      <section className="section page-header">
        <div className="section-inner">
          <p className="eyebrow">Get in Touch</p>
          <h1>Contact Us</h1>
        </div>
      </section>

      <section className="section contact-section">
        <div className="section-inner contact-grid">
          <Reveal className="contact-info">
            <ul className="contact-list">
              <li><Icon name="pin" size={18} /> {BRAND.address}</li>
              <li><Icon name="phone" size={18} /> {BRAND.phone} ({BRAND.phoneOwner})</li>
              <li><Icon name="phone" size={18} /> {BRAND.phone2} ({BRAND.phone2Owner})</li>
              <li><Icon name="whatsapp" size={18} /> {BRAND.phone}</li>
              {BRAND.timings.map((t) => (
                <li key={t.days}><Icon name="chevronRight" size={16} /> {t.days}: {t.hours}</li>
              ))}
              <li><Icon name="chevronRight" size={16} /> {BRAND.holidayNote}</li>
            </ul>
            <div className="contact-actions">
              <a href={waLink} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                <Icon name="whatsapp" size={18} /> Chat on WhatsApp
              </a>
              <a href={BRAND.mapUrl} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
                <Icon name="pin" size={18} /> Get Directions
              </a>
            </div>

            <form className="contact-form" onSubmit={handleSubmit}>
              <h3>Send us a message</h3>
              <input type="text" placeholder="Your name" required />
              <input type="tel" placeholder="Phone number" required />
              <textarea placeholder="How can we help?" rows={4} required />
              <button type="submit" className="btn btn-gold">Send Message</button>
              {sent && <p className="form-success">Thank you, we'll get back to you shortly.</p>}
            </form>
          </Reveal>
          <Reveal delay={100} className="contact-map">
            <iframe
              title="Store location"
              src={BRAND.mapEmbedSrc}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </Reveal>
        </div>
      </section>
    </>
  );
}
