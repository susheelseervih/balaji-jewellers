import React from "react";
import Reveal from "../components/Reveal.jsx";
import StarRating from "../components/StarRating.jsx";
import { TESTIMONIALS } from "../data.js";

export default function ReviewsPage() {
  const total = TESTIMONIALS.length;
  const avg = (TESTIMONIALS.reduce((s, t) => s + t.rating, 0) / total).toFixed(1);
  const breakdown = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: TESTIMONIALS.filter((t) => t.rating === star).length,
  }));

  return (
    <>
      <section className="section page-header">
        <div className="section-inner">
          <p className="eyebrow">Reviews</p>
          <h1>What Our Customers Say</h1>
        </div>
      </section>

      <section className="section reviews-summary">
        <div className="section-inner reviews-summary-grid">
          <Reveal className="reviews-score">
            <span className="reviews-score-number">{avg}</span>
            <StarRating rating={Math.round(avg)} size={20} />
            <p>{total} verified reviews</p>
          </Reveal>
          <Reveal delay={80} className="reviews-breakdown">
            {breakdown.map((b) => (
              <div key={b.star} className="breakdown-row">
                <span>{b.star} star</span>
                <div className="breakdown-bar">
                  <div
                    className="breakdown-fill"
                    style={{ width: `${(b.count / total) * 100}%` }}
                  />
                </div>
                <span>{b.count}</span>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      <section className="section testimonials-section">
        <div className="section-inner">
          <div className="testimonial-grid">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={t.name} delay={i * 50} className="testimonial-card">
                <StarRating rating={t.rating} />
                <p className="testimonial-text">&ldquo;{t.text}&rdquo;</p>
                <p className="testimonial-name">{t.name}</p>
                <p className="testimonial-location">{t.location}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
