import React, { useMemo, useState, useEffect } from "react";
import Icon from "../components/Icon.jsx";
import ProductCard from "../components/ProductCard.jsx";
import Reveal from "../components/Reveal.jsx";
import { PRODUCTS, CATEGORIES, PRICE_BUCKETS } from "../data.js";

export default function Shop({ initialCategory, searchQuery, onOpenProduct }) {
  const [category, setCategory] = useState(initialCategory || "all");
  const [metals, setMetals] = useState([]); // ["Gold","Silver"]
  const [priceBucket, setPriceBucket] = useState("all");
  const [query, setQuery] = useState(searchQuery || "");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [sort, setSort] = useState("relevance");

  useEffect(() => {
    if (initialCategory) setCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    if (searchQuery) setQuery(searchQuery);
  }, [searchQuery]);

  function toggleMetal(m) {
    setMetals((prev) => (prev.includes(m) ? prev.filter((x) => x !== m) : [...prev, m]));
  }

  const filtered = useMemo(() => {
    let list = PRODUCTS.filter((p) => {
      if (category !== "all" && p.category !== category) return false;
      if (metals.length && !metals.includes(p.metal)) return false;
      if (priceBucket !== "all") {
        const bucket = PRICE_BUCKETS.find((b) => b.id === priceBucket);
        if (bucket && (p.price < bucket.min || p.price > bucket.max)) return false;
      }
      if (query && !p.name.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
    if (sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    if (sort === "weight-asc") list = [...list].sort((a, b) => a.weight - b.weight);
    return list;
  }, [category, metals, priceBucket, query, sort]);

  return (
    <section className="section shop-page">
      <div className="section-inner">
        <div className="shop-head">
          <div>
            <p className="eyebrow">Shop</p>
            <h1>All Jewellery</h1>
          </div>
          <div className="shop-search">
            <Icon name="search" size={18} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products..."
            />
          </div>
        </div>

        <button className="btn btn-outline btn-sm filters-toggle" onClick={() => setFiltersOpen((s) => !s)}>
          <Icon name="filter" size={16} /> Filters
        </button>

        <div className="shop-layout">
          <aside className={`shop-filters ${filtersOpen ? "open" : ""}`}>
            <div className="filter-block">
              <h4>Category</h4>
              <label className="filter-option">
                <input
                  type="radio"
                  name="category"
                  checked={category === "all"}
                  onChange={() => setCategory("all")}
                />
                All
              </label>
              {CATEGORIES.map((c) => (
                <label key={c.id} className="filter-option">
                  <input
                    type="radio"
                    name="category"
                    checked={category === c.id}
                    onChange={() => setCategory(c.id)}
                  />
                  {c.name}
                </label>
              ))}
            </div>

            <div className="filter-block">
              <h4>Metal Type</h4>
              {["Gold", "Silver"].map((m) => (
                <label key={m} className="filter-option">
                  <input type="checkbox" checked={metals.includes(m)} onChange={() => toggleMetal(m)} />
                  {m}
                </label>
              ))}
            </div>

            <div className="filter-block">
              <h4>Price</h4>
              <label className="filter-option">
                <input
                  type="radio"
                  name="price"
                  checked={priceBucket === "all"}
                  onChange={() => setPriceBucket("all")}
                />
                Any price
              </label>
              {PRICE_BUCKETS.map((b) => (
                <label key={b.id} className="filter-option">
                  <input
                    type="radio"
                    name="price"
                    checked={priceBucket === b.id}
                    onChange={() => setPriceBucket(b.id)}
                  />
                  {b.label}
                </label>
              ))}
            </div>
          </aside>

          <div className="shop-results">
            <div className="shop-results-head">
              <p>{filtered.length} item{filtered.length !== 1 ? "s" : ""}</p>
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="sort-select">
                <option value="relevance">Sort: Relevance</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="weight-asc">Weight: Low to High</option>
              </select>
            </div>

            {filtered.length === 0 ? (
              <p className="empty-state">No pieces match those filters yet. Try widening your search.</p>
            ) : (
              <div className="product-grid">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
