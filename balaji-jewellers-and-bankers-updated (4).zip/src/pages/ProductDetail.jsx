import React, { useState } from "react";
import Icon from "../components/Icon.jsx";
import { ProductVisual } from "../components/ProductCard.jsx";
import ProductCard from "../components/ProductCard.jsx";
import { PRODUCTS, formatINR } from "../data.js";
import { useShop } from "../context.jsx";

export default function ProductDetail({ productId, onOpenProduct }) {
  const product = PRODUCTS.find((p) => p.id === productId);
  const { addToCart, toggleWishlist, wishlist } = useShop();
  const [qty, setQty] = useState(1);

  if (!product) {
    return (
      <section className="section">
        <div className="section-inner empty-state">
          <p>We couldn't find that piece. It may have been sold or renamed.</p>
          <a href="#/shop" className="btn btn-primary">Back to Shop</a>
        </div>
      </section>
    );
  }

  const isWishlisted = wishlist.includes(product.id);
  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <section className="section product-detail-page">
      <div className="section-inner">
        <a href="#/shop" className="back-link"><Icon name="chevronRight" size={14} className="rotate-180" /> Back to Shop</a>
        <div className="product-detail-grid">
          <div className="product-detail-visual zoom-box">
            <ProductVisual icon={product.icon} className="zoom-target large" />
          </div>
          <div className="product-detail-info">
            <p className="product-meta">{product.metal} &middot; {product.purity} purity</p>
            <h1>{product.name}</h1>
            <p className="product-detail-price">{formatINR(product.price)}</p>
            <p className="product-detail-desc">{product.desc}</p>

            <dl className="spec-list">
              <div><dt>Weight</dt><dd>{product.weight} g</dd></div>
              <div><dt>Purity</dt><dd>{product.purity}</dd></div>
              <div><dt>Metal</dt><dd>{product.metal}</dd></div>
              <div><dt>Hallmark</dt><dd>BIS Certified</dd></div>
            </dl>

            <p className="price-note">
              Price shown is indicative and tied to today's gold rate. Visit or call for a live quote.
            </p>

            <div className="qty-row">
              <span>Quantity</span>
              <div className="qty-stepper">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity">
                  <Icon name="minus" size={14} />
                </button>
                <span>{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} aria-label="Increase quantity">
                  <Icon name="plus" size={14} />
                </button>
              </div>
            </div>

            <div className="product-detail-actions">
              <button className="btn btn-primary btn-lg" onClick={() => addToCart(product.id, qty)}>
                <Icon name="bag" size={18} /> Add to Cart
              </button>
              <button
                className={`btn btn-outline btn-lg ${isWishlisted ? "active" : ""}`}
                onClick={() => toggleWishlist(product.id)}
              >
                <Icon name="heart" size={18} filled={isWishlisted} />
                {isWishlisted ? "Wishlisted" : "Wishlist"}
              </button>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <div className="related-products">
            <h2>You May Also Like</h2>
            <div className="product-grid">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
