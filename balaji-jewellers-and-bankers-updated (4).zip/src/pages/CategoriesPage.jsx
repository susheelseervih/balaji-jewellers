import React from "react";
import Icon from "../components/Icon.jsx";
import Reveal from "../components/Reveal.jsx";
import { CATEGORY_MENU, CUSTOM_ORDERS_LINE, BRAND } from "../data.js";

export default function CategoriesPage() {
  return (
    <>
      <section className="section page-header categories-header">
        <div className="section-inner">
          <p className="eyebrow">Browse By Category</p>
          <h1>Jewellery Categories</h1>
          <p className="categories-subtitle">
            Every piece we carry, organised the way you shop for it.
          </p>
          <div className="custom-orders-chip">
            <Icon name="pencil" size={16} />
            <span>{CUSTOM_ORDERS_LINE.en}</span>
          </div>
          <p className="custom-orders-chip-kn">{CUSTOM_ORDERS_LINE.kn}</p>
        </div>
      </section>

      <section className="section categories-dashboard">
        <div className="section-inner">
          <div className="category-dashboard-grid">
            {CATEGORY_MENU.map((cat, i) => {
              const itemCount = cat.sections.reduce((sum, s) => sum + s.items.length, 0);
              return (
                <Reveal key={cat.id} delay={i * 60}>
                  <a href={`#/categories/${cat.id}`} className={`category-dash-card ${cat.highlight ? "highlight" : ""}`}>
                    <div className="category-dash-icon">
                      <Icon name={cat.icon} size={40} strokeWidth={1.2} />
                    </div>
                    <span className="category-dash-emoji">{cat.emoji}</span>
                    <h3>{cat.name}</h3>
                    <p>{itemCount} item{itemCount !== 1 ? "s" : ""} across {cat.sections.length} section{cat.sections.length !== 1 ? "s" : ""}</p>
                    <span className="category-dash-link">View Category <Icon name="chevronRight" size={14} /></span>
                  </a>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section categories-cta">
        <div className="section-inner categories-cta-inner">
          <div>
            <h2>Don't see exactly what you're picturing?</h2>
            <p>Bring a sketch, a photo, or a family heirloom — we design and cast it in gold or silver, just for you.</p>
          </div>
          <a href={`https://wa.me/${BRAND.whatsapp}`} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-lg">
            <Icon name="whatsapp" size={18} /> Discuss a Custom Order
          </a>
        </div>
      </section>
    </>
  );
}
