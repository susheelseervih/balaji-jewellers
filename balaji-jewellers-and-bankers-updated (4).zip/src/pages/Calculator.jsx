import React, { useMemo, useState } from "react";
import Reveal from "../components/Reveal.jsx";
import Icon from "../components/Icon.jsx";
import { BRAND, formatINR } from "../data.js";

const METALS = {
  gold: {
    label: "Gold",
    icon: "coin",
    accent: "#c9a227",
    accentSoft: "#e7c766",
    gradient: "linear-gradient(135deg, #f5edda 0%, #e7c766 45%, #b08d22 100%)",
    defaultRate: 9800,
  },
  silver: {
    label: "Silver",
    icon: "lamp",
    accent: "#8a97a3",
    accentSoft: "#d7dde2",
    gradient: "linear-gradient(135deg, #f4f6f7 0%, #cfd6db 45%, #8a97a3 100%)",
    defaultRate: 118,
  },
};

function Num({ value }) {
  // simple animated-feeling number, no external deps
  return <span className="calc-num">{value}</span>;
}

export default function Calculator() {
  const [metal, setMetal] = useState("gold");
  const [weight, setWeight] = useState(10);
  const [rate, setRate] = useState(METALS.gold.defaultRate);
  const [making, setMaking] = useState(100);
  const [wastageMode, setWastageMode] = useState("percent"); // 'percent' | 'grams'
  const [wastageValue, setWastageValue] = useState(1);
  const [gstOn, setGstOn] = useState(true);
  const [gstPercent, setGstPercent] = useState(3);

  function switchMetal(next) {
    setMetal(next);
    setRate(METALS[next].defaultRate);
  }

  const calc = useMemo(() => {
    const w = Math.max(0, Number(weight) || 0);
    const r = Math.max(0, Number(rate) || 0);
    const m = Math.max(0, Number(making) || 0);
    const wv = Math.max(0, Number(wastageValue) || 0);

    const wastageGrams = wastageMode === "percent" ? (w * wv) / 100 : wv;
    const effectiveWeight = w + wastageGrams;
    const perGramCost = r + m;
    const subtotal = effectiveWeight * perGramCost;
    const gstAmount = gstOn ? (subtotal * (Number(gstPercent) || 0)) / 100 : 0;
    const total = subtotal + gstAmount;

    return { w, r, m, wastageGrams, effectiveWeight, perGramCost, subtotal, gstAmount, total };
  }, [weight, rate, making, wastageMode, wastageValue, gstOn, gstPercent]);

  const theme = METALS[metal];

  return (
    <>
      <section className="section page-header calc-header" style={{ background: theme.gradient }}>
        <div className="section-inner">
          <p className="eyebrow">Know Before You Buy</p>
          <h1>Gold &amp; Silver Rate Calculator</h1>
          <p className="calc-subtitle">
            Estimate your jewellery cost instantly — transparent, the same way we bill you in-store.
          </p>
        </div>
      </section>

      <section className="section calc-section">
        <div className="section-inner calc-grid">
          <Reveal className="calc-card">
            <div className="metal-toggle">
              {Object.entries(METALS).map(([key, m]) => (
                <button
                  key={key}
                  className={`metal-toggle-btn ${metal === key ? "active" : ""}`}
                  style={metal === key ? { background: m.gradient, borderColor: m.accent } : undefined}
                  onClick={() => switchMetal(key)}
                  type="button"
                >
                  <Icon name={m.icon} size={20} />
                  {m.label}
                </button>
              ))}
            </div>

            <div className="calc-form">
              <label className="calc-field">
                <span>Weight (grams)</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                />
              </label>

              <label className="calc-field">
                <span>Rate (₹ / gram)</span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                />
              </label>

              <label className="calc-field">
                <span>Making Charges (₹ / gram)</span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={making}
                  onChange={(e) => setMaking(e.target.value)}
                />
              </label>

              <div className="calc-field calc-field-wastage">
                <span>Wastage</span>
                <div className="wastage-row">
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={wastageValue}
                    onChange={(e) => setWastageValue(e.target.value)}
                  />
                  <div className="wastage-mode">
                    <button
                      type="button"
                      className={wastageMode === "percent" ? "active" : ""}
                      onClick={() => setWastageMode("percent")}
                    >
                      %
                    </button>
                    <button
                      type="button"
                      className={wastageMode === "grams" ? "active" : ""}
                      onClick={() => setWastageMode("grams")}
                    >
                      grams
                    </button>
                  </div>
                </div>
              </div>

              <label className="calc-field calc-field-gst">
                <span className="gst-label-row">
                  <span>
                    <input
                      type="checkbox"
                      checked={gstOn}
                      onChange={(e) => setGstOn(e.target.checked)}
                    />{" "}
                    Include GST
                  </span>
                  {gstOn && (
                    <input
                      className="gst-percent-input"
                      type="number"
                      min="0"
                      step="0.5"
                      value={gstPercent}
                      onChange={(e) => setGstPercent(e.target.value)}
                    />
                  )}
                </span>
              </label>
            </div>
          </Reveal>

          <Reveal delay={100} className="calc-result-card" style={{ "--metal-accent": theme.accent, "--metal-soft": theme.accentSoft }}>
            <div className="calc-result-glow" style={{ background: theme.gradient }} />
            <p className="eyebrow">Estimated Price</p>
            <div className="calc-total">
              <Num value={formatINR(Math.round(calc.total))} />
            </div>
            <p className="calc-total-caption">
              for {calc.w || 0}g of {theme.label.toLowerCase()} at today's rate
            </p>

            <ul className="calc-breakdown">
              <li>
                <span>Base weight</span>
                <strong>{calc.w.toFixed(2)} g</strong>
              </li>
              <li>
                <span>
                  Wastage ({wastageMode === "percent" ? `${wastageValue}%` : "fixed"})
                </span>
                <strong>+ {calc.wastageGrams.toFixed(3)} g</strong>
              </li>
              <li className="calc-breakdown-highlight">
                <span>Effective weight</span>
                <strong>{calc.effectiveWeight.toFixed(3)} g</strong>
              </li>
              <li>
                <span>Rate + Making (per gram)</span>
                <strong>{formatINR(calc.r)} + {formatINR(calc.m)}</strong>
              </li>
              <li>
                <span>Subtotal</span>
                <strong>{formatINR(Math.round(calc.subtotal))}</strong>
              </li>
              {gstOn && (
                <li>
                  <span>GST ({gstPercent}%)</span>
                  <strong>+ {formatINR(Math.round(calc.gstAmount))}</strong>
                </li>
              )}
              <li className="calc-breakdown-total">
                <span>Grand Total</span>
                <strong>{formatINR(Math.round(calc.total))}</strong>
              </li>
            </ul>

            <p className="calc-formula-note">
              <Icon name="chevronRight" size={14} /> (Weight + Wastage) × (Rate + Making Charges), plus GST if applicable.
            </p>

            <a href={`https://wa.me/${BRAND.whatsapp}`} target="_blank" rel="noopener noreferrer" className="btn btn-primary calc-cta">
              <Icon name="whatsapp" size={18} /> Confirm Today's Rate on WhatsApp
            </a>
          </Reveal>
        </div>

        <p className="calc-disclaimer">
          This is an estimate for reference only. Final billing may vary slightly based on live market rates,
          exact hallmark purity, and design-specific making charges confirmed in-store.
        </p>
      </section>
    </>
  );
}
