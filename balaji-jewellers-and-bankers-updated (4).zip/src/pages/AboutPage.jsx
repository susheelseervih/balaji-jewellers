import React from "react";
import Reveal from "../components/Reveal.jsx";
import Medallion from "../components/Medallion.jsx";
import Icon from "../components/Icon.jsx";
import { BRAND, WHY_CHOOSE_US } from "../data.js";

export default function AboutPage() {
  return (
    <>
      <section className="section page-header">
        <div className="section-inner">
          <p className="eyebrow">About Us</p>
          <h1>Four Decades in the Same Street</h1>
        </div>
      </section>

      <section className="section about-section">
        <div className="section-inner about-grid">
          <Reveal className="about-visual">
            <Medallion size={220}>
              <span className="medallion-center-label">
                <span className="medallion-center-letters">{BRAND.established}</span>
                <span className="medallion-center-sub">Founded</span>
              </span>
            </Medallion>
          </Reveal>
          <Reveal delay={100} className="about-copy">
            <p>
              {BRAND.name} began in {BRAND.established} as a small family pawnbroking
              house in the temple town of {BRAND.city}. In those years, gold was
              weighed on a hand balance for neighbours who needed a loan before
              harvest season, and returned untouched the day they could repay it.
              That promise, that what you hand us is safer with us than anywhere
              else, is still the only promise we make.
            </p>
            <p>
              Four decades on, the ledger books have become showrooms and the loan
              counter now sits beside a bridal collection, but the practice hasn't
              changed. Every piece is hallmarked. Every rate is shown before you
              ask. Every rupee lent against your gold is calculated the same way
              it was for your grandparents.
            </p>
            <p>
              We are, in the same breath, jewellers who craft heirlooms and
              bankers who protect them, a rare combination built one family, one
              wedding, one harvest loan at a time.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="section why-section">
        <div className="section-inner">
          <Reveal as="div" className="section-head">
            <p className="eyebrow">What We Stand For</p>
            <h2>The Promise Behind Every Purchase</h2>
          </Reveal>
          <div className="why-grid">
            {WHY_CHOOSE_US.map((item, i) => (
              <Reveal key={item.title} delay={i * 70} className="why-card">
                <div className="why-badge">
                  <Icon name={item.icon} size={26} strokeWidth={1.2} />
                </div>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
