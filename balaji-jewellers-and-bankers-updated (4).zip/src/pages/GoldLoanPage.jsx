import React from "react";
import Icon from "../components/Icon.jsx";
import Reveal from "../components/Reveal.jsx";
import { GOLD_LOAN_MENU, BRAND } from "../data.js";

export default function GoldLoanPage() {
  return (
    <>
      <section className="section page-header goldloan-header">
        <div className="section-inner">
          <p className="eyebrow">Balaji Bankers</p>
          <h1>Gold Loan</h1>
          <div className="category-banner goldloan-banner">{GOLD_LOAN_MENU.banner}</div>
          <p className="categories-subtitle">
            Turn your gold into instant financial strength — fair valuation, fast disbursal, safe storage.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="section-inner">
          <div className="goldloan-grid">
            {GOLD_LOAN_MENU.items.map((item, i) => (
              <Reveal key={item.name} delay={i * 60} className="goldloan-card">
                <div className="goldloan-icon">
                  <Icon name={item.icon} size={36} strokeWidth={1.2} />
                </div>
                <h3>{item.name}</h3>
                <p>{item.desc}</p>
              </Reveal>
            ))}
          </div>

          <div className="category-detail-cta">
            <p>Walk in with your gold — walk out with cash, the same day.</p>
            <a href={`https://wa.me/${BRAND.whatsapp}?text=${encodeURIComponent("Hi, I'd like to enquire about a gold loan")}`} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-lg">
              <Icon name="whatsapp" size={18} /> Enquire About Gold Loan
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
