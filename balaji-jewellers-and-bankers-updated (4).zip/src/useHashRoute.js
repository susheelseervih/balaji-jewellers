import { useEffect, useState, useCallback } from "react";

export function useHashRoute() {
  const [hash, setHash] = useState(() => window.location.hash || "#/");

  useEffect(() => {
    const onChange = () => setHash(window.location.hash || "#/");
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const navigate = useCallback((to) => {
    window.location.hash = to;
  }, []);

  // Parse "#/product/p1" -> { path: "product", params: ["p1"] }
  const clean = hash.replace(/^#\/?/, "");
  const segments = clean.split("/").filter(Boolean);
  const path = segments[0] || "home";
  const params = segments.slice(1);

  return { hash, path, params, navigate };
}
