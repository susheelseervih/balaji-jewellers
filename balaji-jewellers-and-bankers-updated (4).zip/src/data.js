// All site content lives here so copy can be edited without touching components.

export const HERO_SLIDES = [
  {
    id: "brand",
    kind: "brand",
    eyebrow: "Est. 1988 · Devalapura",
    title: "35+ Years of Trust, Tradition & Excellence",
    titleKannada: "35+ ವರ್ಷಗಳ ವಿಶ್ವಾಸ, ಪರಂಪರೆ ಮತ್ತು ಶ್ರೇಷ್ಠತೆ",
    subtitle: "Jewellers who craft heirlooms. Bankers who protect them.",
    taglineKannada: "ನಿಮ್ಮ ವಿಶ್ವಾಸವೇ ನಮ್ಮ ಶಕ್ತಿ",
    ctaPrimary: { label: "Shop Gold", href: "#/categories/gold" },
    ctaSecondary: { label: "Explore Collections", href: "#/categories" },
  },
  {
    id: "bridal-banner",
    kind: "image",
    image: "hero/slide-bridal.jpg",
    alt: "Balaji Jewellers — Timeless Tradition, Eternal Beauty, Exquisite South Indian Gold Jewellery",
    href: "#/categories/bridal",
  },
  {
    id: "groom-banner",
    kind: "image",
    image: "hero/slide-groom.jpg",
    alt: "Balaji Jewellers — Timeless Tradition, Eternal Beauty, Gold Jewellery for Every Occasion",
    href: "#/categories",
  },
  {
    id: "silver-banner",
    kind: "image",
    image: "hero/slide-silver.jpg",
    alt: "Balaji Jewellers — Pure Silver, Pure Elegance, 925 Pure Silver Collection",
    href: "#/categories/silver",
  },
  {
    id: "goldloan-banner",
    kind: "image",
    image: "hero/slide-goldloan.jpg",
    alt: "Balaji Jewellers — Turn Your Gold into Financial Strength, Instant Gold Loan",
    href: "#/gold-loan",
  },
];

export const BRAND = {
  name: "Balaji Jewellers and Bankers",
  short: "BJB",
  established: 1984,
  city: "Nagamangala",
  phone: "+91 97423 40637",
  phoneOwner: "Dinesh",
  phone2: "+91 93535 45650",
  phone2Owner: "Susheel",
  whatsapp: "919742340637",
  email: "hello@balajijewellers.example",
  address: "Yadiur Main Road, Devalapura, Nagamangala, Mandya - 571445",
  mapUrl: "https://www.google.com/maps/place/Balaji+Jewellers/@12.8179524,76.8681686,221m/data=!3m1!1e3!4m15!1m8!3m7!1s0x3bafbfab8b84047f:0x3d728739edbdd8d1!2sDevalapura,+Karnataka+571445!3b1!8m2!3d12.817146!4d76.867772!16s%2Fg%2F11r7pxfcs!3m5!1s0x3bafbf1a92443dff:0x78b8b0e2656dc22e!8m2!3d12.8171101!4d76.8692804!16s%2Fg%2F11pkdqsjxk?hl=en&entry=ttu&g_ep=EgoyMDI2MDcwNi4wIKXMDSoASAFQAw%3D%3D",
  mapEmbedSrc: "https://www.google.com/maps?q=12.8171101,76.8692804&z=17&output=embed",
  timings: [
    { days: "All Days", hours: "9:00 AM – 7:30 PM" },
  ],
  holidayNote: "Closed on Amavasya & Pournami (No Moon & Full Moon Days)",
};

export const CATEGORIES = [
  {
    id: "gold",
    icon: "necklace",
    name: "Gold Jewellery",
    desc: "Necklaces, chains, bangles & rings, finished to BIS hallmark standard.",
  },
  {
    id: "silver",
    icon: "lamp",
    name: "Silver Items",
    desc: "Pooja items, utensils and gifting silver for every occasion.",
  },
  {
    id: "bridal",
    icon: "bridal",
    name: "Bridal Collections",
    desc: "Complete bridal sets designed to carry a story into the next generation.",
  },
  {
    id: "daily",
    icon: "chain",
    name: "Daily Wear",
    desc: "Lightweight gold for the everyday, without the everyday price.",
  },
  {
    id: "coins",
    icon: "coin",
    name: "Coins & Investment Gold",
    desc: "BIS hallmarked coins in 999 and 916 purity, for saving in gold.",
  },
];

export const COLLECTIONS = [
  {
    id: "bridal-collection",
    name: "Bridal Jewellery",
    desc: "Layered necklaces, vaddanams and sets built for the wedding season and beyond.",
  },
  {
    id: "temple",
    name: "Temple Jewellery",
    desc: "Kemp stones and antique motifs drawn from South Indian temple architecture.",
  },
  {
    id: "lightweight",
    name: "Lightweight Jewellery",
    desc: "Everyday gold under 10 grams, priced and designed for daily wear.",
  },
  {
    id: "trending",
    name: "Trending Designs",
    desc: "This season's most requested pieces, updated as new designs arrive.",
  },
];

export const WHY_CHOOSE_US = [
  {
    icon: "shield",
    title: "35+ Years of Trust",
    desc: "Three generations of the same family, the same promise.",
  },
  {
    icon: "certificate",
    title: "BIS Hallmarked Gold",
    desc: "Every piece certified for purity, no exceptions.",
  },
  {
    icon: "scale",
    title: "Transparent Pricing",
    desc: "Today's rate, shown before you buy, not after.",
  },
  {
    icon: "pencil",
    title: "Custom Jewellery Design",
    desc: "Bring a sketch, a photo, or a memory. We'll cast it in gold.",
  },
  {
    icon: "vault",
    title: "Gold Loans & Banking",
    desc: "Fair valuation, fast disbursal, your gold kept safe till the last rupee is repaid.",
  },
  {
    icon: "lock",
    title: "Secure Transactions",
    desc: "Vaulted storage, insured transit, and billing you can verify anytime.",
  },
];

export const BANKING_SERVICES = [
  {
    icon: "vault",
    title: "Gold Loans",
    desc: "Borrow against your gold at transparent, RBI-guided rates.",
  },
  {
    icon: "handshake",
    title: "Pawn Broking",
    desc: "Short-term loans against gold and silver, disbursed the same day.",
  },
  {
    icon: "scale",
    title: "Instant Valuation",
    desc: "Walk in, get your gold weighed and valued in minutes.",
  },
  {
    icon: "lock",
    title: "Safe & Secure Process",
    desc: "Insured vault storage, and a signed receipt for every gram.",
  },
];

export const TESTIMONIALS = [
  {
    name: "Lakshmi Narayanan",
    location: "Thanjavur",
    rating: 5,
    text: "Three generations of my family have bought their wedding jewellery here. The purity is never in question.",
  },
  {
    name: "Rajesh Kumar",
    location: "Trichy",
    rating: 5,
    text: "Took a gold loan against my wife's bangles during a medical emergency. Approved in twenty minutes, gold returned exactly as we left it.",
  },
  {
    name: "Meena Sundaram",
    location: "Chennai",
    rating: 4,
    text: "Beautiful lightweight collection for daily wear. Wish they had more branches outside Tamil Nadu.",
  },
  {
    name: "Karthik Raja",
    location: "Madurai",
    rating: 5,
    text: "Best quality gold and very trustworthy service! The hallmark certificate came with every piece.",
  },
  {
    name: "Divya Prakash",
    location: "Thanjavur",
    rating: 5,
    text: "Got temple jewellery custom made for my daughter's arangetram. It exceeded what I had imagined.",
  },
  {
    name: "Suresh Babu",
    location: "Salem",
    rating: 4,
    text: "Transparent pricing, no pressure to buy. They explained the making charges line by line.",
  },
  {
    name: "Priya Venkatesh",
    location: "Coimbatore",
    rating: 5,
    text: "The gold loan process was faster than my bank. My gold came back safe and exactly as valued.",
  },
  {
    name: "Anand Subramaniam",
    location: "Thanjavur",
    rating: 5,
    text: "Bought my mother's 60th birthday gift here. The staff spent an hour helping us choose without any pressure.",
  },
];

// icon field references the shared <Icon name=".."/> component
export const PRODUCTS = [
  {
    id: "p1",
    name: "Temple Kasu Mala Necklace",
    category: "bridal",
    metal: "Gold",
    purity: "22K",
    weight: 45.2,
    price: 385000,
    icon: "necklace",
    desc: "A traditional coin necklace strung with hand-finished Lakshmi kasu, worked in the temple style Thanjavur is known for.",
  },
  {
    id: "p2",
    name: "Antique Gold Jhumka Earrings",
    category: "bridal",
    metal: "Gold",
    purity: "22K",
    weight: 12.8,
    price: 108000,
    icon: "earring",
    desc: "Antique-finish jhumkas with a gentle sway, light enough for daily wear and rich enough for a wedding.",
  },
  {
    id: "p3",
    name: "Lightweight Gold Chain",
    category: "daily",
    metal: "Gold",
    purity: "22K",
    weight: 8.5,
    price: 72500,
    icon: "chain",
    desc: "A slim, everyday chain designed to be worn and forgotten about, in the best way.",
  },
  {
    id: "p4",
    name: "Bridal Kemp Choker Set",
    category: "bridal",
    metal: "Gold",
    purity: "22K",
    weight: 68,
    price: 578000,
    icon: "bridal",
    desc: "A complete choker and earring set finished with kemp stonework, built for the wedding day and every anniversary after.",
  },
  {
    id: "p5",
    name: "Classic Gold Bangles (Pair)",
    category: "daily",
    metal: "Gold",
    purity: "22K",
    weight: 24,
    price: 204000,
    icon: "bangle",
    desc: "A pair of everyday bangles in a rounded, comfortable profile that pairs with both silk and cotton.",
  },
  {
    id: "p6",
    name: "Diamond-Studded Gold Ring",
    category: "daily",
    metal: "Gold",
    purity: "18K",
    weight: 4.2,
    price: 58000,
    icon: "ring",
    desc: "A single-stone ring set in 18K gold, sized and polished while you wait.",
  },
  {
    id: "p7",
    name: "Silver Kuthu Vilakku",
    category: "silver",
    metal: "Silver",
    purity: "999",
    weight: 320,
    price: 28800,
    icon: "lamp",
    desc: "A traditional standing lamp in fine silver, for the home or as a housewarming gift.",
  },
  {
    id: "p8",
    name: "Silver Pooja Thali Set",
    category: "silver",
    metal: "Silver",
    purity: "999",
    weight: 180,
    price: 16200,
    icon: "lamp",
    desc: "A complete pooja thali in silver, with the kumkum and lamp bowls sold as one set.",
  },
  {
    id: "p9",
    name: "24K Gold Coin — Lakshmi, 8g",
    category: "coins",
    metal: "Gold",
    purity: "999",
    weight: 8,
    price: 72800,
    icon: "coin",
    desc: "A BIS hallmarked 999 purity coin, sealed and certified, priced to today's rate.",
  },
  {
    id: "p10",
    name: "24K Gold Coin — Lakshmi, 4g",
    category: "coins",
    metal: "Gold",
    purity: "999",
    weight: 4,
    price: 36400,
    icon: "coin",
    desc: "The smaller sibling of our 8g coin, a common choice for gifting at weddings and Diwali.",
  },
  {
    id: "p11",
    name: "Vaddanam Bridal Waist Belt",
    category: "bridal",
    metal: "Gold",
    purity: "22K",
    weight: 95,
    price: 807500,
    icon: "bridal",
    desc: "A heavyweight bridal waist belt, made to order and fitted in-store before the wedding date.",
  },
  {
    id: "p12",
    name: "Matte Finish Gold Studs",
    category: "daily",
    metal: "Gold",
    purity: "22K",
    weight: 3.6,
    price: 30600,
    icon: "earring",
    desc: "Small, matte-finished studs for daily wear at the office or over a saree.",
  },
  {
    id: "p13",
    name: "Silver Anklets (Pair)",
    category: "silver",
    metal: "Silver",
    purity: "925",
    weight: 90,
    price: 8100,
    icon: "bangle",
    desc: "Sterling silver anklets with a soft bell chime, sold as a pair.",
  },
  {
    id: "p14",
    name: "Gold Vanki Armlet",
    category: "bridal",
    metal: "Gold",
    purity: "22K",
    weight: 18,
    price: 153000,
    icon: "bridal",
    desc: "A traditional upper-arm ornament, worked in temple motifs, worn with bridal silk.",
  },
];

export const PRICE_BUCKETS = [
  { id: "under-50k", label: "Under \u20b950,000", min: 0, max: 50000 },
  { id: "50k-2l", label: "\u20b950,000 \u2013 \u20b92,00,000", min: 50000, max: 200000 },
  { id: "2l-5l", label: "\u20b92,00,000 \u2013 \u20b95,00,000", min: 200000, max: 500000 },
  { id: "above-5l", label: "Above \u20b95,00,000", min: 500000, max: Infinity },
];

export function formatINR(n) {
  return "\u20b9" + n.toLocaleString("en-IN");
}

// Full jewellery category taxonomy used by the Jewellery Categories mega-menu
// and the category dashboard pages. Each item gets an icon (no product
// photography is available yet -- see ProductCard.jsx for the same note).
export const CATEGORY_MENU = [
  {
    id: "gold",
    emoji: "\ud83d\udfe1",
    name: "Gold",
    icon: "necklace",
    banner: "\u2728 Custom Orders Available (Gold & Silver \u2013 Men, Women & Kids)",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Lakshmi Kasu (Kasu Mala)", icon: "tali", image: "categories/gold/lakshmi-kasu.jpg" },
          { name: "Tali (Mangalsutra South Style)", icon: "tali", image: "categories/gold/tali.jpg" },
          { name: "Necklaces", icon: "necklace", image: "categories/gold/necklaces.jpg" },
          { name: "Chains", icon: "chain", image: "categories/gold/chains.jpg" },
          { name: "Mangalsutra", icon: "tali", image: "categories/gold/mangalsutra.jpg" },
          { name: "Bangles & Kadas", icon: "bangle", image: "categories/gold/bangles-kadas.jpg" },
          { name: "Rings", icon: "ring", image: "categories/gold/rings.jpg" },
          { name: "Earrings", icon: "earring", image: "categories/gold/earrings.jpg" },
          { name: "Pendants", icon: "necklace", image: "categories/gold/pendants.jpg" },
          { name: "Nose Pins", icon: "nosePin", image: "categories/gold/nose-pins.jpg" },
        ],
      },
      {
        title: "More",
        collapsible: true,
        items: [
          { name: "Jhumka / Jumki", icon: "earring" },
          { name: "Gondhu Drops", icon: "earring" },
          { name: "Bracelets", icon: "bracelet" },
          { name: "Baby Earrings", icon: "earring" },
          { name: "Daily Wear Jewellery", icon: "chain" },
          { name: "Mattal (Ear Chain)", icon: "mattal" },
          { name: "Anklets in Gold", icon: "anklet" },
        ],
      },
    ],
  },
  {
    id: "silver",
    emoji: "\u26aa",
    name: "Silver",
    icon: "lamp",
    banner: "\u2728 Custom Orders Available (Gold & Silver \u2013 Men, Women & Kids)",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Silver Chains", icon: "chain" },
          { name: "Silver Rings", icon: "ring" },
          { name: "Silver Anklets (Payal / Leg Chain)", icon: "anklet" },
          { name: "Silver Kada (Hand Kada)", icon: "bangle" },
          { name: "Silver Kalungura (Toe Rings)", icon: "ring" },
          { name: "Silver Champu (Hair Accessories)", icon: "hairAccessory" },
        ],
      },
      {
        title: "Pooja & Traditional",
        items: [
          { name: "Deepa (Lamps)", icon: "lamp" },
          { name: "Silver Plates", icon: "plate" },
          { name: "Idols (God Idols)", icon: "idol" },
          { name: "Pooja Sets", icon: "lamp" },
        ],
      },
      {
        title: "Gifting",
        items: [
          { name: "Silver Coins", icon: "coin" },
          { name: "Gift Articles", icon: "gift" },
          { name: "Baby Gifts (Silver Glass, Spoon, etc.)", icon: "gift" },
        ],
      },
    ],
  },
  {
    id: "bridal",
    emoji: "\ud83d\udc8d",
    name: "Bridal",
    icon: "bridal",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Bridal Sets (Full Combo)", icon: "bridal" },
          { name: "Temple Jewellery", icon: "necklace" },
          { name: "Antique Jewellery", icon: "necklace" },
          { name: "Vaddanam (Waist Belt)", icon: "vaddanam" },
          { name: "Bridal Bangles", icon: "bangle" },
          { name: "Bridal Tali Sets", icon: "tali" },
        ],
      },
    ],
  },
  {
    id: "diamond",
    emoji: "\ud83d\udc8e",
    name: "Diamond",
    icon: "diamond",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Diamond Rings", icon: "diamond" },
          { name: "Diamond Earrings", icon: "diamond" },
        ],
      },
    ],
  },
  {
    id: "daily-wear",
    emoji: "\ud83d\udc57",
    name: "Daily Wear",
    icon: "chain",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Lightweight Chains", icon: "chain" },
          { name: "Simple Rings", icon: "ring" },
          { name: "Small Earrings", icon: "earring" },
          { name: "Office Wear Jewellery", icon: "chain" },
        ],
      },
    ],
  },
  {
    id: "gifts",
    emoji: "\ud83c\udf81",
    name: "Gifts",
    icon: "gift",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Gold Coins", icon: "coin" },
          { name: "Silver Coins", icon: "coin" },
          { name: "Customized Jewellery", icon: "pencil" },
          { name: "Baby Jewellery", icon: "gift" },
          { name: "Festive Gifts", icon: "gift" },
        ],
      },
    ],
  },
  {
    id: "kids",
    emoji: "\u2b50",
    name: "Kids Jewellery",
    icon: "kids",
    highlight: true,
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Baby Earrings", icon: "earring" },
          { name: "Baby Bangles", icon: "bangle" },
          { name: "Kids Chains", icon: "chain" },
          { name: "Kids Rings", icon: "ring" },
          { name: "Nazariya (Evil-Eye Charms)", icon: "kids" },
        ],
      },
    ],
  },
  {
    id: "mens",
    emoji: "\ud83d\udc54",
    name: "Men's Jewellery",
    icon: "chain",
    sections: [
      {
        title: "Main Items",
        items: [
          { name: "Gold Chains (Thick)", icon: "chain" },
          { name: "Bracelets", icon: "bracelet" },
          { name: "Rings", icon: "ring" },
        ],
      },
    ],
  },
];

export const GOLD_LOAN_MENU = {
  banner: "\ud83d\udd25 Instant Loan on Gold \u2013 Quick & Secure",
  items: [
    { name: "Gold Loan Service", icon: "vault", desc: "Borrow against your gold at transparent, RBI-guided rates." },
    { name: "Instant Cash", icon: "coin", desc: "Walk out with cash in hand the same day." },
    { name: "Gold Valuation", icon: "scale", desc: "Fair, transparent weighing and valuation before you commit." },
    { name: "Safe Storage", icon: "lock", desc: "Insured vault storage until every rupee is repaid." },
    { name: "Easy Repayment Options", icon: "handshake", desc: "Flexible tenures and part-payment options that work around you." },
  ],
};

export const CUSTOM_ORDERS_LINE = {
  en: "We Accept Custom Orders \u2013 Designed Just For You",
  kn: "ನಿಮಗಾಗಿ ವಿಶೇಷವಾಗಿ ತಯಾರಿಸುವ ಆಭರಣಗಳು ಲಭ್ಯ",
};
