import React from "react";
import Reveal from "../components/Reveal.jsx";
import Icon from "../components/Icon.jsx";
import { WHY_CHOOSE_US } from "../data.js";

export default function WhyChooseUs() {
  return (
    <section className="section why-section">
      <div className="section-inner">
        <Reveal as="div" className="section-head">
          <p className="eyebrow">Why Choose Us</p>
          <h2>Six Reasons Families Come Back</h2>
        </Reveal>
        <div className="why-grid">
          {WHY_CHOOSE_US.map((item, i) => (
            <Reveal key={item.title} delay={i * 70} className="why-card">
              <div className="why-badge">
                <Icon name={item.icon} size={26} strokeWidth={1.2} />
              </div>
              <h3>{item.title}</h3>
              <p>{item.desc}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
