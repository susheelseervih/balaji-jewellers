import React from "react";
import Reveal from "../components/Reveal.jsx";
import Icon from "../components/Icon.jsx";
import { CATEGORY_MENU } from "../data.js";

export default function Categories() {
  const featured = CATEGORY_MENU.filter((c) => !["kids", "mens"].includes(c.id));
  return (
    <section className="section categories-section">
      <div className="section-inner">
        <Reveal as="div" className="section-head">
          <p className="eyebrow">Browse</p>
          <h2>Jewellery Categories</h2>
        </Reveal>
        <div className="category-grid">
          {featured.map((cat, i) => {
            const itemCount = cat.sections.reduce((sum, s) => sum + s.items.length, 0);
            return (
              <Reveal key={cat.id} delay={i * 80}>
                <a href={`#/categories/${cat.id}`} className="category-card">
                  <div className="category-icon">
                    <Icon name={cat.icon} size={34} strokeWidth={1.1} />
                  </div>
                  <h3>{cat.emoji} {cat.name}</h3>
                  <p>{itemCount} curated items across {cat.sections.length} section{cat.sections.length !== 1 ? "s" : ""}.</p>
                  <span className="category-link">
                    Explore <Icon name="chevronRight" size={14} />
                  </span>
                </a>
              </Reveal>
            );
          })}
        </div>
        <div className="categories-viewall">
          <a href="#/categories" className="btn btn-outline">View All Categories</a>
        </div>
      </div>
    </section>
  );
}
