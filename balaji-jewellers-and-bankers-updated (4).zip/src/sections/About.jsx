import React from "react";
import Reveal from "../components/Reveal.jsx";
import Medallion from "../components/Medallion.jsx";
import { BRAND } from "../data.js";

export default function About() {
  return (
    <section className="section about-section">
      <div className="section-inner about-grid">
        <Reveal className="about-visual" as="div">
          <Medallion size={220}>
            <span className="medallion-center-label">
              <span className="medallion-center-letters">35+</span>
              <span className="medallion-center-sub">Years</span>
            </span>
          </Medallion>
        </Reveal>
        <Reveal className="about-copy" delay={100}>
          <p className="eyebrow">Our Story</p>
          <h2>A ledger that became a legacy</h2>
          <p>
            {BRAND.name} began in {BRAND.established} as a small family pawnbroking
            house in the temple town of {BRAND.city}, weighing gold for neighbours
            who needed a loan before harvest season, and returning it untouched
            the day they could repay. That promise is still the only one we make.
          </p>
          <p>
            Four decades on, the ledger books have become showrooms and the loan
            counter now sits beside a bridal collection, but the practice hasn't
            changed: every piece is hallmarked, every rate is shown before you
            ask, and every rupee lent against your gold is calculated the same
            way it was for your grandparents.
          </p>
          <p className="pull-quote">
            "We are, in the same breath, jewellers who craft heirlooms and
            bankers who protect them."
          </p>
          <a href="#/about" className="btn btn-ghost">
            Read our full story
          </a>
        </Reveal>
      </div>
    </section>
  );
}
