import React from "react";
import Reveal from "../components/Reveal.jsx";
import Icon from "../components/Icon.jsx";
import { BANKING_SERVICES } from "../data.js";

export default function BankingServices() {
  return (
    <section className="section banking-section">
      <div className="ledger-lines" aria-hidden="true" />
      <div className="section-inner">
        <Reveal as="div" className="section-head light">
          <p className="eyebrow">The Banking Counter</p>
          <h2>Gold Loans &amp; Pawn Broking</h2>
          <p className="section-sub">
            The other half of our name. Fast, fair, and documented at every step.
          </p>
        </Reveal>
        <div className="banking-grid">
          {BANKING_SERVICES.map((item, i) => (
            <Reveal key={item.title} delay={i * 80} className="banking-card">
              <Icon name={item.icon} size={30} strokeWidth={1.1} />
              <h3>{item.title}</h3>
              <p>{item.desc}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="banking-cta">
          <a href="#/contact" className="btn btn-gold btn-lg">Get a Free Gold Valuation</a>
        </Reveal>
      </div>
    </section>
  );
}
