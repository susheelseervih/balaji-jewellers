import React from "react";
import Reveal from "../components/Reveal.jsx";
import { COLLECTIONS } from "../data.js";

export default function FeaturedCollections() {
  return (
    <section className="section collections-section">
      <div className="section-inner">
        <Reveal as="div" className="section-head light">
          <p className="eyebrow">Featured</p>
          <h2>This Season's Collections</h2>
        </Reveal>
        <div className="collection-strip">
          {COLLECTIONS.map((col, i) => (
            <Reveal key={col.id} delay={i * 90} className="collection-card">
              <span className="collection-mark" aria-hidden="true" />
              <h3>{col.name}</h3>
              <p>{col.desc}</p>
              <a href="#/categories" className="collection-link">View pieces</a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
