import React, { useEffect, useState, useCallback, useRef } from "react";
import Icon from "../components/Icon.jsx";
import WomanFigure from "../components/WomanFigure.jsx";
import { BRAND, HERO_SLIDES } from "../data.js";

const AUTO_ADVANCE_MS = 3000;
const IMAGE_ASPECT = 941 / 1672; // height / width, matches the uploaded banner images

function textSlideHeight(width) {
  if (width <= 480) return 540;
  if (width <= 640) return 580;
  if (width <= 860) return 640;
  if (width <= 1024) return 600;
  return 620;
}

function computeSlideHeight(slide, width) {
  if (slide.kind === "image") {
    // Fit the full image at this width, capped so it doesn't get absurdly tall on wide desktops.
    const naturalHeight = width * IMAGE_ASPECT;
    const cap = textSlideHeight(width);
    return Math.round(Math.min(naturalHeight, cap));
  }
  return textSlideHeight(width);
}

function Slide({ slide }) {
  if (slide.kind === "brand") {
    return (
      <div className="hero-inner">
        <div className="hero-copy">
          <p className="eyebrow">{slide.eyebrow}</p>
          <h1>{slide.title}</h1>
          {slide.titleKannada && <p className="hero-title-kn">{slide.titleKannada}</p>}
          <p className="hero-sub">{slide.subtitle}</p>
          {slide.taglineKannada && <p className="hero-tagline-kn">{slide.taglineKannada}</p>}
          <div className="hero-actions">
            {slide.ctaPrimary && (
              <a href={slide.ctaPrimary.href} className="btn btn-primary btn-lg">
                {slide.ctaPrimary.label}
              </a>
            )}
            {slide.ctaSecondary && (
              <a href={slide.ctaSecondary.href} className="btn btn-outline btn-lg">
                {slide.ctaSecondary.label}
              </a>
            )}
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-illustration-frame medallion-shimmer brand-frame">
            <img src="logo.png" alt={`${BRAND.name} logo`} className="hero-logo" />
          </div>
        </div>
      </div>
    );
  }

  if (slide.kind === "image") {
    const img = <img src={slide.image} alt={slide.alt || ""} className="hero-banner-img" />;
    return (
      <div className="hero-image-slide">
        {slide.href ? (
          <a href={slide.href} aria-label={slide.alt || "View collection"}>
            {img}
          </a>
        ) : (
          img
        )}
      </div>
    );
  }

  return (
    <div className="hero-figure-slide">
      <div className="hero-bg-figure">
        <WomanFigure jewelry={slide.figure} />
      </div>
      <div className="hero-scrim" />
      <div className="hero-inner-figure">
        <p className="eyebrow">{slide.eyebrow}</p>
        <h1>{slide.title}</h1>
        <p className="hero-sub">{slide.subtitle}</p>
        <div className="hero-actions">
          {slide.ctaPrimary && (
            <a href={slide.ctaPrimary.href} className="btn btn-primary btn-lg">
              {slide.ctaPrimary.label}
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [vpHeight, setVpHeight] = useState(620);
  const viewportRef = useRef(null);
  const count = HERO_SLIDES.length;

  const goTo = useCallback((i) => setIndex(((i % count) + count) % count), [count]);
  const next = useCallback(() => goTo(index + 1), [goTo, index]);
  const prev = useCallback(() => goTo(index - 1), [goTo, index]);

  useEffect(() => {
    const reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (paused || reduceMotion) return undefined;
    const timer = setInterval(() => setIndex((i) => (i + 1) % count), AUTO_ADVANCE_MS);
    return () => clearInterval(timer);
  }, [paused, count]);

  useEffect(() => {
    function recompute() {
      const width = viewportRef.current ? viewportRef.current.clientWidth : window.innerWidth;
      setVpHeight(computeSlideHeight(HERO_SLIDES[index], width));
    }
    recompute();
    window.addEventListener("resize", recompute);
    return () => window.removeEventListener("resize", recompute);
  }, [index]);

  return (
    <section
      className="hero"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="hero-viewport" ref={viewportRef} style={{ height: `${vpHeight}px` }}>
        <div className="hero-track" style={{ transform: `translateX(-${index * 100}%)` }}>
          {HERO_SLIDES.map((slide) => (
            <div className="hero-slide" key={slide.id} aria-hidden={slide.id !== HERO_SLIDES[index].id}>
              <Slide slide={slide} />
            </div>
          ))}
        </div>

        <button className="hero-arrow prev" onClick={prev} aria-label="Previous slide">
          <Icon name="chevronRight" size={18} className="rotate-180" />
        </button>
        <button className="hero-arrow next" onClick={next} aria-label="Next slide">
          <Icon name="chevronRight" size={18} />
        </button>

        <div className="hero-dots" role="tablist" aria-label="Hero slides">
          {HERO_SLIDES.map((slide, i) => (
            <button
              key={slide.id}
              className={`hero-dot ${i === index ? "active" : ""}`}
              onClick={() => goTo(i)}
              role="tab"
              aria-selected={i === index}
              aria-label={`Show slide ${i + 1}: ${slide.title || slide.alt || "banner"}`}
            />
          ))}
        </div>
      </div>
      <div className="coin-edge" />
    </section>
  );
}
