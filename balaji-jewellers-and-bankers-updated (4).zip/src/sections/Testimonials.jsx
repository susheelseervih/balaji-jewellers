import React from "react";
import Reveal from "../components/Reveal.jsx";
import StarRating from "../components/StarRating.jsx";
import { TESTIMONIALS } from "../data.js";

export default function Testimonials() {
  const shown = TESTIMONIALS.slice(0, 6);
  return (
    <section className="section testimonials-section">
      <div className="section-inner">
        <Reveal as="div" className="section-head">
          <p className="eyebrow">Testimonials</p>
          <h2>What Our Customers Say</h2>
        </Reveal>
        <div className="testimonial-grid">
          {shown.map((t, i) => (
            <Reveal key={t.name} delay={i * 60} className="testimonial-card">
              <StarRating rating={t.rating} />
              <p className="testimonial-text">&ldquo;{t.text}&rdquo;</p>
              <p className="testimonial-name">{t.name}</p>
              <p className="testimonial-location">{t.location}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="testimonials-cta">
          <a href="#/reviews" className="btn btn-ghost">Read all reviews</a>
        </Reveal>
      </div>
    </section>
  );
}
