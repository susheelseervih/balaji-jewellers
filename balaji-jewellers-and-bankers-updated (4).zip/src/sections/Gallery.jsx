import React from "react";
import Reveal from "../components/Reveal.jsx";
import { GALLERY } from "../data.js";

export default function Gallery() {
  return (
    <section className="section gallery-section">
      <div className="section-inner">
        <Reveal as="div" className="section-head">
          <p className="eyebrow">Inside the Showroom</p>
          <h2>Store Gallery</h2>
        </Reveal>
        <div className="gallery-grid">
          {GALLERY.map((g, i) => (
            <Reveal key={g.id} delay={i * 60} className="gallery-frame">
              <div className="gallery-placeholder">
                <span>{g.label}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
