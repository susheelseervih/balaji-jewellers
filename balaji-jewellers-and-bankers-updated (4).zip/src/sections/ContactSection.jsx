import React from "react";
import Reveal from "../components/Reveal.jsx";
import Icon from "../components/Icon.jsx";
import { BRAND } from "../data.js";

export default function ContactSection() {
  const waLink = `https://wa.me/${BRAND.whatsapp}`;

  return (
    <section className="section contact-section">
      <div className="section-inner contact-grid">
        <Reveal className="contact-info">
          <p className="eyebrow">Visit Us</p>
          <h2>Contact &amp; Location</h2>
          <ul className="contact-list">
            <li><Icon name="pin" size={18} /> {BRAND.address}</li>
            <li><Icon name="phone" size={18} /> {BRAND.phone} ({BRAND.phoneOwner})</li>
            <li><Icon name="phone" size={18} /> {BRAND.phone2} ({BRAND.phone2Owner})</li>
            {BRAND.timings.map((t) => (
              <li key={t.days}><Icon name="chevronRight" size={16} /> {t.days}: {t.hours}</li>
            ))}
            <li><Icon name="chevronRight" size={16} /> {BRAND.holidayNote}</li>
          </ul>
          <div className="contact-actions">
            <a href={waLink} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              <Icon name="whatsapp" size={18} /> Chat on WhatsApp
            </a>
            <a href={BRAND.mapUrl} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
              <Icon name="pin" size={18} /> Get Directions
            </a>
          </div>
        </Reveal>
        <Reveal delay={100} className="contact-map">
          <iframe
            title="Store location"
            src={BRAND.mapEmbedSrc}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </Reveal>
      </div>
    </section>
  );
}
