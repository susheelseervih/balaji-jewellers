import React, { useState } from "react";
import { ShopProvider, useShop } from "./context.jsx";
import { useHashRoute } from "./useHashRoute.js";
import Navbar from "./components/Navbar.jsx";
import Footer from "./components/Footer.jsx";
import WhatsAppFAB from "./components/WhatsAppFAB.jsx";
import Drawer from "./components/Drawer.jsx";
import Icon from "./components/Icon.jsx";
import { ProductVisual } from "./components/ProductCard.jsx";
import { PRODUCTS, formatINR } from "./data.js";

import Home from "./pages/Home.jsx";
import Shop from "./pages/Shop.jsx";
import ProductDetail from "./pages/ProductDetail.jsx";
import AboutPage from "./pages/AboutPage.jsx";
import ContactPage from "./pages/ContactPage.jsx";
import ReviewsPage from "./pages/ReviewsPage.jsx";
import Calculator from "./pages/Calculator.jsx";
import CategoriesPage from "./pages/CategoriesPage.jsx";
import CategoryDetail from "./pages/CategoryDetail.jsx";
import GoldLoanPage from "./pages/GoldLoanPage.jsx";

function CartDrawer() {
  const { cart, cartOpen, setCartOpen, removeFromCart, updateQty } = useShop();
  const items = cart
    .map((entry) => ({ ...entry, product: PRODUCTS.find((p) => p.id === entry.id) }))
    .filter((entry) => entry.product);
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.qty, 0);

  return (
    <Drawer open={cartOpen} onClose={() => setCartOpen(false)} title="Your Cart">
      {items.length === 0 ? (
        <p className="empty-state">Your cart is empty.</p>
      ) : (
        <>
          <ul className="drawer-list">
            {items.map(({ product, qty }) => (
              <li key={product.id} className="drawer-item">
                <ProductVisual icon={product.icon} className="drawer-thumb" />
                <div className="drawer-item-info">
                  <p className="drawer-item-name">{product.name}</p>
                  <p className="drawer-item-meta">{formatINR(product.price)} &times; {qty}</p>
                  <div className="qty-stepper small">
                    <button onClick={() => updateQty(product.id, qty - 1)} aria-label="Decrease">
                      <Icon name="minus" size={12} />
                    </button>
                    <span>{qty}</span>
                    <button onClick={() => updateQty(product.id, qty + 1)} aria-label="Increase">
                      <Icon name="plus" size={12} />
                    </button>
                  </div>
                </div>
                <button className="icon-btn" onClick={() => removeFromCart(product.id)} aria-label="Remove">
                  <Icon name="close" size={16} />
                </button>
              </li>
            ))}
          </ul>
          <div className="drawer-footer">
            <div className="drawer-subtotal">
              <span>Subtotal</span>
              <strong>{formatINR(subtotal)}</strong>
            </div>
            <a href="#/contact" className="btn btn-primary btn-lg" onClick={() => setCartOpen(false)}>
              Enquire to Checkout
            </a>
          </div>
        </>
      )}
    </Drawer>
  );
}

function WishlistDrawer({ onOpenProduct }) {
  const { wishlist, wishlistOpen, setWishlistOpen, toggleWishlist, addToCart } = useShop();
  const items = wishlist.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean);

  return (
    <Drawer open={wishlistOpen} onClose={() => setWishlistOpen(false)} title="Your Wishlist">
      {items.length === 0 ? (
        <p className="empty-state">Nothing saved yet. Tap the heart on any piece to save it here.</p>
      ) : (
        <ul className="drawer-list">
          {items.map((product) => (
            <li key={product.id} className="drawer-item">
              <ProductVisual icon={product.icon} className="drawer-thumb" />
              <div className="drawer-item-info">
                <p
                  className="drawer-item-name link"
                  onClick={() => {
                    setWishlistOpen(false);
                    onOpenProduct(product.id);
                  }}
                >
                  {product.name}
                </p>
                <p className="drawer-item-meta">{formatINR(product.price)}</p>
                <button className="btn btn-ghost btn-sm" onClick={() => addToCart(product.id)}>
                  Add to Cart
                </button>
              </div>
              <button className="icon-btn" onClick={() => toggleWishlist(product.id)} aria-label="Remove">
                <Icon name="close" size={16} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </Drawer>
  );
}

function Shell() {
  const { path, params, navigate } = useHashRoute();
  const [searchQuery, setSearchQuery] = useState("");

  function openProduct(id) {
    navigate(`#/product/${id}`);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, [path, params.join("/")]);

  let page;
  if (path === "home") page = <Home />;
  else if (path === "shop") page = <Shop initialCategory={params[0]} searchQuery={searchQuery} onOpenProduct={openProduct} />;
  else if (path === "product") page = <ProductDetail productId={params[0]} onOpenProduct={openProduct} />;
  else if (path === "about") page = <AboutPage />;
  else if (path === "contact") page = <ContactPage />;
  else if (path === "reviews") page = <ReviewsPage />;
  else if (path === "calculator") page = <Calculator />;
  else if (path === "categories" && !params[0]) page = <CategoriesPage />;
  else if (path === "categories" && params[0]) page = <CategoryDetail categoryId={params[0]} />;
  else if (path === "gold-loan") page = <GoldLoanPage />;
  else page = <Home />;

  return (
    <div className="site-shell">
      <Navbar currentPath={path} onSearch={setSearchQuery} />
      <main>{page}</main>
      <Footer />
      <WhatsAppFAB />
      <CartDrawer />
      <WishlistDrawer onOpenProduct={openProduct} />
    </div>
  );
}

export default function App() {
  return (
    <ShopProvider>
      <Shell />
    </ShopProvider>
  );
}
